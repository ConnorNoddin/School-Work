#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>
#include <signal.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <sys/ioctl.h>

int main(int argc, char *argv[])
{
	pid_t pid;
	
	int fd, ret, msg_len, i;
	
	char *msg;
	
	fd = open("/dev/lcd", O_WRONLY);
	
	if (fd < 0) {
		fprintf(stderr, "Error, failed to open the character device\n");
		return -1;
	}
	
	/* Tests multiple processes writing. Tests locking */
	for (i = 0; i < 3; i++) {
		pid = fork();
		/* Checks for errors with fork() */
		if (pid < 0) {
			fprintf(stderr, "Error: Fork failed to create a new process\n");
			exit(-1);
		}
		/* if child process, write CHILD */
		else if (pid == 0) {
			msg = "CHILD";
			msg_len = strlen(msg);
			
			printf("Wrote CHILD\n");
		
			ret = write(fd, msg, msg_len);
			if (ret < 0) {
				fprintf(stderr, "Error, failed to write to the character device\n");
				return -1;
			}
		}
		/* if parent process, write PARENT */
		else {
			msg = "PARENT";
			msg_len = strlen(msg);
			
			printf("Wrote PARENT\n");
		
			ret = write(fd, msg, msg_len);
			if (ret < 0) {
				fprintf(stderr, "Error, failed to write to the character device\n");
				return -1;
			}
		}
	}
	
	/*
	 * NOTE: On the LCD, no PARENT should be inside CHILD (or vice versa)
	 */
	
	return 0;
}
