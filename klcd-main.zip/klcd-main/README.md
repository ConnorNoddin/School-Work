# LCD Driver ECE 331 Spring 2022 Project 02

## Authors
Connor Noddin

## Install
Extract files to desired directory.

## Usage

### Run "make" command to build kernel object. Run "-make -f TestMakeFile" to build test files.

### Run "sudo insmod lcd.ko" to insert the LCD driver.

### Run "lsmod" to check to see if the insertion was successful. "LCD" should appear

### Run "./singletest" to run a singlethreaded test that tests ioctl and writing

### Run "./multitest" to run a multithreaded test that tests locking

### Run "./edgetest" to run a singlethreaded test that tests edge cases for writing

### Run "./reversetest" to run a singlethreaded tests that tests writing in the reverse direction

### Run "sudo rmmod lcd" to remove the LCD driver
