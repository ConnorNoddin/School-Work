/* 
* Connor Noddin - LCD Driver
* 3/11/2022
* Creates a kernel driver that operates
* an LCD from the Raspberry Pi GPIO
*/
#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/device.h>
#include <linux/err.h>
#include <linux/fs.h>
#include <linux/spinlock.h>
#include <linux/delay.h>
#include <linux/list.h>
#include <linux/io.h>
#include <linux/ioctl.h>
#include <linux/uaccess.h>
#include <linux/irq.h>
#include <linux/interrupt.h>
#include <linux/slab.h>
#include <linux/gpio.h>
#include <linux/of_gpio.h>
#include <linux/platform_device.h>
#include <linux/pinctrl/consumer.h>
#include <linux/gpio/consumer.h>
#include <linux/jiffies.h>
#include <linux/mutex.h>

#include "lcd.h"

static int lcd_pin_set(u8 inst, unsigned long t);
static int lcd_clock(unsigned long t);
static int lcd_dwrite(unsigned char letter);
static int lcd_iwrite(u8 inst0, u8 inst1);
static int lcd_fix_pos(void);

// Data to be "passed" around to various functions
struct lcd_data_t {
	struct gpio_desc *gpio_lcd_rs;		// LCD RS pin
	struct gpio_desc *gpio_lcd_e;		// LCD E pin
	struct gpio_desc *gpio_lcd_d4;		// LCD D4 pin
	struct gpio_desc *gpio_lcd_d5;		// LCD D5 pin
	struct gpio_desc *gpio_lcd_d6;		// LCD D6 pin
	struct gpio_desc *gpio_lcd_d7;		// LCD D7 pin
	struct class *lcd_class;			// Class for auto /dev population
	struct device *lcd_dev;				// Device for auto /dev population
	struct platform_device *pdev;		// Platform driver
	int lcd_major;						// Device major number
	int lcd_cursor;						// Value for current cursor position
	int lcd_dir;						// Value for forwards or reverse writing direction
	int lcd_ioctl_value;				// Value for IOCTL input 
	struct mutex lcd_lock;				// Mutex lock data structure
};

// LCD data structure access between functions
static struct lcd_data_t *lcd_dat=NULL;

/* Sets rs, d7, d6 ,d5, d4, then clocks the output with a delay */
static int lcd_pin_set(u8 inst, unsigned long t)
{
	/* No error checking as function here returns void */
	gpiod_set_value(lcd_dat->gpio_lcd_rs, (inst >> 4) & 1);
	gpiod_set_value(lcd_dat->gpio_lcd_d7, (inst >> 3) & 1);
	gpiod_set_value(lcd_dat->gpio_lcd_d6, (inst >> 2) & 1);
	gpiod_set_value(lcd_dat->gpio_lcd_d5, (inst >> 1) & 1);
	gpiod_set_value(lcd_dat->gpio_lcd_d4, inst & 1);
	lcd_clock(t);
	
	return 0;
}

/* Sets the clock to 1, then back to 0 after a delay */
static int lcd_clock(unsigned long t)
{
	/* No error checking as funciton here returns void */
	gpiod_set_value(lcd_dat->gpio_lcd_e, 1);
	/*
	* This value should be adjusted depending on the quality of the LCD
	* I had a very low quality LCD (not he one handed out in class)
	* and this was required to get it to perform consistently
	*/
	usleep_range (4000, 5000);
	gpiod_set_value(lcd_dat->gpio_lcd_e, 0);
	//This delay is used for particular functions, for example during init
	usleep_range (t, t + 100);
	
	return 0;
}

/* Writes data to the current cursor position */
static int lcd_dwrite(unsigned char letter)
{
	int col, row, error;
	
	error = lcd_fix_pos();
	
	/* Calculates upper and lower half to send to LCD */
	col = ((letter & 0xF0) >> 4) | 0x10;
	row = (letter & 0x0F) | 0x10;
	
	lcd_pin_set(col, 10);
	
	lcd_pin_set(row, 10);
	
	/* LCD is set to increment the cursor every time a character is written */
	lcd_dat->lcd_cursor = lcd_dat->lcd_cursor + lcd_dat->lcd_dir;

	return 0;
}

/* 
 * Fixes postition of cursor for 2 line display
 * This function will change depending on the display used (resolution).
 * Works for both forward and reverse
 */
static int lcd_fix_pos(void)
{
	int i;
	/* Forward direction onto line 2 */
	if ((lcd_dat->lcd_cursor == 16) && (lcd_dat->lcd_dir == 1)) {
		lcd_iwrite(0x00, LCD_HOME);
		for (i = 0; i < 40; i++) {
			lcd_iwrite(0x01,0x04);
		}
		lcd_dat->lcd_cursor = 40;
		return 0;
	/* Forward direction onto line 1 */
	} else if ((lcd_dat->lcd_cursor == 56) && (lcd_dat->lcd_dir == 1)) {
		lcd_iwrite(0x00, LCD_HOME);
		lcd_dat->lcd_cursor = 0;
		return 0;
	/* Reverse direction onto line 1 */
	} else if ((lcd_dat->lcd_cursor == 39) && (lcd_dat->lcd_dir == -1)) {
		lcd_iwrite(0x00, LCD_HOME);
		for (i = 0; i < 15; i++) {
			lcd_iwrite(0x01,0x04);
		}
		lcd_dat->lcd_cursor = 15;
		return 0;
	/* Reverse direction onto line 2 */	
	} else if ((lcd_dat->lcd_cursor == -1) && (lcd_dat->lcd_dir == -1)) {
		lcd_iwrite(0x00, LCD_HOME);
		for (i = 0; i < 55; i++) {
			lcd_iwrite(0x01,0x04);
		}
		lcd_dat->lcd_cursor = 55;
		return 0;
	}
	
	return 0;
}

/* Writes two 4 bit instructions. */
static int lcd_iwrite(u8 inst0, u8 inst1)
{	
	/* 5th bit is r/w pin. Typically 0 for instruction writes */
	
	lcd_pin_set(inst0, 10);
	
	lcd_pin_set(inst1, 10);
	
	return 0;
}

// ioctl system call
// If an LCD instruction is the command then
//   use arg directly as the value (8 bits) and write to the LCD as an instruction
// Determine if locking is needed and add appropriate code as needed.
static long lcd_ioctl(struct file *filp, unsigned int cmd, unsigned long arg)
{
	u8 inst0, inst1;
	int error, i;
	
	/* Determine if valid cmd value is entered */
	if (cmd == WR_VALUE) {
		if (copy_from_user(&(lcd_dat->lcd_ioctl_value), (int32_t *) arg, sizeof(lcd_dat->lcd_ioctl_value))) {
			printk(KERN_INFO "Error, error copying from user\n");
			return -EFAULT;
		}
	} else {
		printk(KERN_INFO "Error, invalid argument. Enter 8 bit instruction\n");
		return -ENOTTY; /* It is debated to use this or -EINVAL */
	}
	
	/* Gathers the instructions for arg */
	inst0 = (lcd_dat->lcd_ioctl_value >> 4) & 0x0F;
	inst1 = lcd_dat->lcd_ioctl_value & 0x0F;
	
	/* 
	 * If file is opened non-blocking and lock is held returns with try again 
	 * We do want to lock here as multiple ioctl calls that interweave will
	 * give unexpected results
	 */
	if ((filp->f_flags & O_NONBLOCK) && (mutex_is_locked(&(lcd_dat->lcd_lock)))) {
		printk(KERN_INFO "Error, file is opened non-blocking and and lock is held\n");
		return -EAGAIN;
	} else {
		/* Lock, checking for errors */
		error = mutex_lock_interruptible(&(lcd_dat->lcd_lock));
		if (error) {
			printk(KERN_INFO "Error, locking interrupted\n");
			return -EINTR;
		}	
	}
	
	/* 
	 * Writes instructions from arg to LCD
	 * CAUTION: Depending on instruction used lcd_cursor will
	 * be messed up, causing wrapping errors. To solve this, input 10xx
	 * as your ioctl argument whereas xx is the position you would like to
	 * place your cursor
	 */
	 
	/* Adds functionality to place cursor in desired position */
	if ((lcd_dat->lcd_ioctl_value < 1016) && (lcd_dat->lcd_ioctl_value >= 1000)) {
		lcd_iwrite(0x00, LCD_HOME);
		for (i = 0; i < (lcd_dat->lcd_ioctl_value - 1000); i++) {
			lcd_iwrite(0x01,0x04);
		}
		lcd_dat->lcd_cursor = lcd_dat->lcd_ioctl_value - 1000;	
	} else if ((lcd_dat->lcd_ioctl_value >= 1016) && (lcd_dat->lcd_ioctl_value < 1032)){
		lcd_iwrite(0x00, LCD_HOME);
		for (i = 0; i < 40 + (lcd_dat->lcd_ioctl_value - 1016); i++) {
			lcd_iwrite(0x01,0x04);
		}
		lcd_dat->lcd_cursor = 40 + (lcd_dat->lcd_ioctl_value - 1000);	
	/* Detects if display direction is being changed */
	} else if ((inst0 == LCD_BASE) && (inst1 == LCD_WRITE)) {
		error = lcd_iwrite(inst0, inst1);
		lcd_dat->lcd_dir = 1;
	} else if ((inst0 == LCD_BASE) && (inst1 == 0x04)) {
		error = lcd_iwrite(inst0, inst1);
		lcd_dat->lcd_dir = -1;
	} else if ((inst0 == LCD_BASE) && (inst1 == LCD_HOME)) {
		error = lcd_iwrite(inst0, inst1);
		lcd_dat->lcd_cursor = 0;
	} else {
		error = lcd_iwrite(inst0, inst1);
	}
	/* Unlocks mutex */
	mutex_unlock(&(lcd_dat->lcd_lock));

	return 0;
}

// Write system call - always check for and act appropriately upon error.
//  DO not return upon while holding a lock
// maximum write size to the LCD is 32 bytes.
//   Do not allow any more.  Return the minimum of count or 32, or an error.
// allocate memory in the kernel for data passed from user space
// copy the data
// If the file is opened non-blocking and the lock is held,
//   return with an appropraite error
// else
//   If the lock is held,
//     Wait until the lock is released and then acquire the lock
//     if while waiting for the lock, the user process is interrupted
//       return with and error
//   else
//     Acquire the lock
// Write up to the first 32 bytes of data to the LCD at the proper location
// release the lock
// Free memory
// This function return the number of byte successfully writen
static ssize_t lcd_write(struct file *filp, const char __user *buf, size_t count, loff_t *offp)
{
	int error, i;
	unsigned char let;
	unsigned char *ubuf;
	
	/* Kernel memory allocation, only allocates up to 32 bytes */	
	if (count > 32) {
		ubuf = (unsigned char *) kmalloc(32+1, GFP_ATOMIC);
		count = 32;
		if (ubuf == NULL) {
			printk(KERN_INFO "Error allocating memory for the character buffer\n");
			return -ENOMEM;
		}	
		
	} else if ((count > 0) && (count <= 32)) {
		ubuf = (unsigned char *) kmalloc(count+1, GFP_ATOMIC);
		if (ubuf == NULL) {
			printk(KERN_INFO "Error allocating memory for the character buffer\n");
			return -ENOMEM;
		}	
	} else {
		printk(KERN_INFO "Warning, no bytes written to LCD\n");
		/* 
		 * Returns EFAULT as nothing was input.
		 * could be argued to return 0 as 0 is the number of bytes written
		*/
		return -EFAULT;
	}
	
	/* Copies data from userspace, a maximum of 32 bytes */
	error = copy_from_user(ubuf, buf, count);
	if (error) {
		printk(KERN_INFO "Error copying buffer from user space\n");
		kfree(ubuf);
		return -EFAULT;
	}
	
	/* If file is opened non-blocking and lock is held returns with try again */
	if ((filp->f_flags & O_NONBLOCK) && (mutex_is_locked(&(lcd_dat->lcd_lock)))) {
		printk(KERN_INFO "Error, file is opened non-blocking and and lock is held\n");
		kfree(ubuf);
		return -EAGAIN;
	} else {
		/* Lock, checking for errors */
		error = mutex_lock_interruptible(&(lcd_dat->lcd_lock));
		if (error) {
			printk(KERN_INFO "Error, locking interrupted\n");
			kfree(ubuf);
			return -EINTR;
		}	
	}
	
	/* Writes each letter in buffer from userspace */
	for (i = 0; i < count; i++) {
		let = ubuf[i];
		lcd_dwrite(let);
	}
	
	/* Unlocks mutex */
	mutex_unlock(&(lcd_dat->lcd_lock));
	
	/* Frees memory buffer */
	kfree(ubuf);
	ubuf = NULL;

	if (count > 32) {
		return 32;
	} else {
		return count;
	}
}

// Open system call
// Open only if the file access flags (NOT permissions) are appropiate as discussed in class
// Return an appropraite error otherwise
static int lcd_open(struct inode *inode, struct file *filp)
{
	/* Checks if mutex is currently locked */
	if (mutex_is_locked(&(lcd_dat->lcd_lock))) {
		printk(KERN_INFO "Warning, mutex is currently locked \n");
		return -EBUSY;
	}
	
	/* Checks is file is opened in write only */
	if (!(filp->f_flags & O_WRONLY)) {
		return -EINVAL;
	}
	printk(KERN_INFO "File opened successfully\n");

	return 0;
}

// Close system call
static int lcd_release(struct inode *inode, struct file *filp)
{
	if (mutex_is_locked(&(lcd_dat->lcd_lock))) {
		printk(KERN_INFO "Warning, mutex is currently locked. Will be destroyed upon module removal. \n");
		return -EBUSY;
	}
	printk(KERN_INFO "File closed successfully\n");

    return 0;
}

// File operations for the lcd device.  Uninitialized will be NULL.
static const struct file_operations lcd_fops = {
	.owner = THIS_MODULE,	// Us
	.open = lcd_open,		// Open
	.release = lcd_release,// Close
	.write = lcd_write,	// Write
	.unlocked_ioctl=lcd_ioctl,	// ioctl
};

// Init value<0 means input
static struct gpio_desc *lcd_obtain_pin(struct device *dev, int pin, char *name, int init_val)
{
	struct gpio_desc *gpiod_pin=NULL;	// GPIO Descriptor for setting value
	int ret=-1;	// Return value

	// Request the pin - release with devm_gpio_free() by pin number
	if (init_val>=0) {
		ret=devm_gpio_request_one(dev,pin,GPIOF_OUT_INIT_LOW,name);
		if (ret<0) {
			dev_err(dev,"Cannot get %s gpio pin\n",name);
			gpiod_pin=NULL;
			goto fail;
		}
	} else {
		ret=devm_gpio_request_one(dev,pin,GPIOF_IN,name);
		if (ret<0) {
			dev_err(dev,"Cannot get %s gpio pin\n",name);
			gpiod_pin=NULL;
			goto fail;
		}
	}

	// Get the gpiod pin struct
	gpiod_pin=gpio_to_desc(pin);
	if (gpiod_pin==NULL) {
		printk(KERN_INFO "Failed to acquire lcd gpio\n");
		gpiod_pin=NULL;
		goto fail;
	}

	// Make sure the pin is set correctly
	if (init_val>=0) gpiod_set_value(gpiod_pin,init_val);

	return gpiod_pin;

fail:
	if (ret>=0) devm_gpio_free(dev,pin);

	return gpiod_pin;
}


// Sets device node permission on the /dev device special file
static char *lcd_devnode(struct device *dev, umode_t *mode)
{
	/* Declares permissions using macros on device special file */
	if (mode) *mode = S_IRUGO | S_IWUGO;
	return NULL;
}

// This is called on module load.
static int __init lcd_probe(void)
{
	int ret=-1;	// Return value

	// Allocate device driver data and save
	lcd_dat=kmalloc(sizeof(struct lcd_data_t),GFP_KERNEL);
	if (lcd_dat==NULL) {
		printk(KERN_INFO "Memory allocation failed\n");
		return -ENOMEM;
	}

	memset(lcd_dat,0,sizeof(struct lcd_data_t));

	// Create the device - automagically assign a major number
	lcd_dat->lcd_major=register_chrdev(0,"lcd",&lcd_fops);
	if (lcd_dat->lcd_major<0) {
		printk(KERN_INFO "Failed to register character device\n");
		ret=lcd_dat->lcd_major;
		goto fail;
	}

	// Create a class instance
	lcd_dat->lcd_class=class_create(THIS_MODULE, "lcd_class");
	if (IS_ERR(lcd_dat->lcd_class)) {
		printk(KERN_INFO "Failed to create class\n");
		ret=PTR_ERR(lcd_dat->lcd_class);
		goto fail;
	}

	// Setup the device so the device special file is created with 0666 perms
	lcd_dat->lcd_class->devnode=lcd_devnode;
	lcd_dat->lcd_dev=device_create(lcd_dat->lcd_class,NULL,MKDEV(lcd_dat->lcd_major,0),(void *)lcd_dat,"lcd");
	if (IS_ERR(lcd_dat->lcd_dev)) {
		printk(KERN_INFO "Failed to create device file\n");
		ret=PTR_ERR(lcd_dat->lcd_dev);
		goto fail;
	}

	lcd_dat->gpio_lcd_rs=lcd_obtain_pin(lcd_dat->lcd_dev,17,"LCD_RS",0);
	if (lcd_dat->gpio_lcd_rs==NULL) goto fail;
	lcd_dat->gpio_lcd_e=lcd_obtain_pin(lcd_dat->lcd_dev,27,"LCD_E",0);
	if (lcd_dat->gpio_lcd_e==NULL) goto fail;
	lcd_dat->gpio_lcd_d4=lcd_obtain_pin(lcd_dat->lcd_dev,6,"LCD_D4",0);
	if (lcd_dat->gpio_lcd_d4==NULL) goto fail;
	lcd_dat->gpio_lcd_d5=lcd_obtain_pin(lcd_dat->lcd_dev,13,"LCD_D5",0);
	if (lcd_dat->gpio_lcd_d5==NULL) goto fail;
	lcd_dat->gpio_lcd_d6=lcd_obtain_pin(lcd_dat->lcd_dev,19,"LCD_D5",0);
	if (lcd_dat->gpio_lcd_d6==NULL) goto fail;
	lcd_dat->gpio_lcd_d7=lcd_obtain_pin(lcd_dat->lcd_dev,26,"LCD_D7",0);
	if (lcd_dat->gpio_lcd_d7==NULL) goto fail;

	/* Initializes the mutex lock */
	mutex_init(&(lcd_dat->lcd_lock));
	printk(KERN_INFO "Mutex initialized\n");
	
	/* Initializes the LCD in 8 bit mode */
	lcd_pin_set(LCD_INIT, 4200);
	lcd_pin_set(LCD_INIT, 125);
	lcd_pin_set(LCD_INIT, 50);
	lcd_pin_set(LCD_HOME, 50);

	/* Initialized the LCD in 4 bit mode */
	lcd_iwrite(LCD_HOME, LCD_ON_OFF);
	lcd_iwrite(LCD_BASE, LCD_ON_OFF);
	lcd_iwrite(LCD_BASE, LCD_CLR);
	lcd_iwrite(LCD_BASE, LCD_ENTRY_MODE);
	lcd_iwrite(LCD_BASE, LCD_ALL);
	
	/* Begin Cursor */
	lcd_iwrite(LCD_BASE, LCD_WRITE);
	
	/* Inits cursor to position 0 */
	lcd_dat->lcd_cursor = 0;
	
	/* Inits IOCTL Value */
	lcd_dat->lcd_ioctl_value = 0;
	
	/* Inits LCD direction Value */
	lcd_dat->lcd_dir = 1;
	
	printk(KERN_INFO "LCD initialized\n");

	printk(KERN_INFO "Registered\n");

	return 0;

fail:
	if (lcd_dat->gpio_lcd_d7) devm_gpio_free(lcd_dat->lcd_dev,desc_to_gpio(lcd_dat->gpio_lcd_d7));
	if (lcd_dat->gpio_lcd_d6) devm_gpio_free(lcd_dat->lcd_dev,desc_to_gpio(lcd_dat->gpio_lcd_d6));
	if (lcd_dat->gpio_lcd_d5) devm_gpio_free(lcd_dat->lcd_dev,desc_to_gpio(lcd_dat->gpio_lcd_d5));
	if (lcd_dat->gpio_lcd_d4) devm_gpio_free(lcd_dat->lcd_dev,desc_to_gpio(lcd_dat->gpio_lcd_d4));
	if (lcd_dat->gpio_lcd_e) devm_gpio_free(lcd_dat->lcd_dev,desc_to_gpio(lcd_dat->gpio_lcd_e));
	if (lcd_dat->gpio_lcd_rs) devm_gpio_free(lcd_dat->lcd_dev,desc_to_gpio(lcd_dat->gpio_lcd_rs));

	// Device cleanup
	if (lcd_dat->lcd_dev) device_destroy(lcd_dat->lcd_class,MKDEV(lcd_dat->lcd_major,0));
	// Class cleanup
	if (lcd_dat->lcd_class) class_destroy(lcd_dat->lcd_class);
	// char dev clean up
	if (lcd_dat->lcd_major) unregister_chrdev(lcd_dat->lcd_major,"lcd");

	if (lcd_dat!=NULL) kfree(lcd_dat);
	printk(KERN_INFO "LCD Failed\n");
	return ret;
}

// Called when the module is removed
static void __exit lcd_remove(void)
{
	// Free the gpio pins with devm_gpio_free() & gpiod_put()
	devm_gpio_free(lcd_dat->lcd_dev,desc_to_gpio(lcd_dat->gpio_lcd_d7));
	devm_gpio_free(lcd_dat->lcd_dev,desc_to_gpio(lcd_dat->gpio_lcd_d6));
	devm_gpio_free(lcd_dat->lcd_dev,desc_to_gpio(lcd_dat->gpio_lcd_d5));
	devm_gpio_free(lcd_dat->lcd_dev,desc_to_gpio(lcd_dat->gpio_lcd_d4));
	devm_gpio_free(lcd_dat->lcd_dev,desc_to_gpio(lcd_dat->gpio_lcd_e));
	devm_gpio_free(lcd_dat->lcd_dev,desc_to_gpio(lcd_dat->gpio_lcd_rs));

	// Device cleanup
	device_destroy(lcd_dat->lcd_class,MKDEV(lcd_dat->lcd_major,0));
	// Class cleanup
	class_destroy(lcd_dat->lcd_class);
	// Remove char dev
	unregister_chrdev(lcd_dat->lcd_major,"lcd");
	
	//Remove Mutex
	mutex_destroy(&(lcd_dat->lcd_lock));
	printk(KERN_INFO "Mutex destroyed\n");
	
	// Free the device driver data
	if (lcd_dat!=NULL) {
		kfree(lcd_dat);
		lcd_dat=NULL;
	}

	printk(KERN_INFO "Removed\n");
}

module_init(lcd_probe);
module_exit(lcd_remove);

MODULE_DESCRIPTION("RPI R-2R LCD");
MODULE_LICENSE("GPL");
MODULE_DESCRIPTION("LCD");
#include <linux/kernel.h>
#include <linux/gpio.h>
#include <linux/gpio/consumer.h>
#include <linux/delay.h>
#include "lcd.h"
