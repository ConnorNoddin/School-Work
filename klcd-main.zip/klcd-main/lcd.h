/*
* Connor Noddin
* 3/11/2022
* LCD Kernel Driver
*/
#ifndef LCD_H
#define LCD_H

#include <linux/types.h>
#include <asm/ioctl.h>

/* For more about the LCD, visit http://users.ece.utexas.edu/~valvano/Datasheets/LCDOptrex.pdf */

/* Define statements for LCD instructions */
#define LCD_BASE 0x00 /* Used for 8 bit functions converted to 4 bit */
#define LCD_CLR 0x01 /* Clears the entire display */
#define LCD_HOME 0x02 /* Returns home */
#define LCD_WRITE 0x06 /* Starts write for LCD */
#define LCD_ALL 0x0F /* All options for writing */

#define LCD_INIT 0x03 /* 4 Bit Initialization */

#define LCD_ENTRY_MODE 0x04 /* Entry set mode, decrement and no shifting */
#define LCD_ENTRY_MODE_ID 0x02 /* Sets direction of incrementation */
#define LCD_ENTRY_MODE_S 0x01 /* Enables display shifitng */

#define LCD_ON_OFF 0x08 /* Display ON/OFF Control */
#define LCD_ON_OFF_D 0x04 /* Sets entire display to on or off */
#define LCD_ON_OFF_C 0x02 /* Sets the cursor to on or off */
#define LCD_ON_OFF_B 0x01 /* Sets cursor blinking to on or off */

#define LCD_CRSR_DISP_SHIFT 0x10 /* Cursor or display shift */
#define LCD_CRSR_DISP_SHIFT_S 0x08 /* Sets display to shift */
#define LCD_CRSR_DISP_SHIFT_R 0x04 /* Sets direction of display to right */

#define LCD_FNCT 0x20 /* 4 bit 1 line mode */
#define LCD_FNCT_DL 0x10; /* 8 bit mode */
#define LCD_FNCT_N 0x08 /* 2 line mode */
#define LCD_FNCT_F 0x04 /* 5x10 dot mode */

#define LCD_SET_CG_ADDR 0x40 /* Set CG RAM address */
#define LCD_SET_DD_ADDR 0x80 /* Set DD RAM address */

#define IOCTL_BASE 0xFACADE /* Magic Number */
#define IOCTL_SUP 0xCAFE /* Command Number */
#define WR_VALUE _IOW(IOCTL_BASE, IOCTL_SUP, int32_t*) /* Ioctl Write Value */

#endif	// LCD_H
