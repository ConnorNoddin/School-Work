#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <fcntl.h>
#include <sys/ioctl.h>

#define IOCTL_BASE 0xFACADE /* Magic Number */
#define IOCTL_SUP 0xCAFE /* Command Number */
#define WR_VALUE _IOW(IOCTL_BASE, IOCTL_SUP, int32_t*) /* Ioctl Write Value */

int main(int argc, char *argv[])
{
	int fd, ret, msg_len;
	
	int instruction = 0x02;
	int forwardinst = 0x06;
	
	char *msg;
	
	fd = open("/dev/lcd", O_WRONLY);
	
	if (fd < 0) {
		fprintf(stderr, "Error, failed to open the character device\n");
		return -1;
	}
	
	/* Starts test as position 0 */
	ret = ioctl(fd, WR_VALUE, (int32_t *) &instruction);
	if (ret < 0) {
		fprintf(stderr, "Error, failed to use ioctl on character device\n");
		return -1;
	}
	
	/* Makes sure forward write mode is set*/
	ret = ioctl(fd, WR_VALUE, (int32_t *) &forwardinst);
	if (ret < 0) {
		fprintf(stderr, "Error, failed to use ioctl on character device\n");
		return -1;
	}

	msg = "Testing 1 2 3.";
	msg_len = strlen(msg);

	ret = write(fd, msg, msg_len);
	if (ret < 0) {
		fprintf(stderr, "Error, failed to write to the character device\n");
		return -1;
	}
	
	/* Tests wrapping */
	msg = "Lets see some wrapping";
	msg_len = strlen(msg);

	ret = write(fd, msg, msg_len);
	if (ret < 0) {
		fprintf(stderr, "Error, failed to write to the character device\n");
		return -1;
	}
	
	ret = ioctl(fd, WR_VALUE, (int32_t *) &instruction);
	if (ret < 0) {
		fprintf(stderr, "Error, failed to use ioctl on character device\n");
		return -1;
	}
	
	/* Tests writing back at beginning */
	msg = "BACK TO START";
	msg_len = strlen(msg);

	ret = write(fd, msg, msg_len);
	if (ret < 0) {
		fprintf(stderr, "Error, failed to write to the character device\n");
		return -1;
	}
	
	close(fd);
	
	return 0;
}
