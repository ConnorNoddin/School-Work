#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <fcntl.h>
#include <sys/ioctl.h>

#define IOCTL_BASE 0xFACADE /* Magic Number */
#define IOCTL_SUP 0xCAFE /* Command Number */
#define WR_VALUE _IOW(IOCTL_BASE, IOCTL_SUP, int32_t*) /* Ioctl Write Value */

int main(int argc, char *argv[])
{
	int fd, ret, msg_len;
	
	/* Reverse write direction */
	int instruction = 0x04;
	
	char *msg;
	
	fd = open("/dev/lcd", O_WRONLY);
	
	/* Checks for errors if device fails to open */
	if (fd < 0) {
		fprintf(stderr, "Error, failed to open the character device\n");
		return -1;
	}

	msg = "I am writing backwards!";
	msg_len = strlen(msg);
	
	/* Begin Writing Backwards */
	ret = ioctl(fd, WR_VALUE, (int32_t *) &instruction);
	if (ret < 0) {
		fprintf(stderr, "Error, failed to use ioctl on character device\n");
		return -1;
	}

	/* Writes message. Reverse direction happens behind the scenes */
	ret = write(fd, msg, msg_len);
	if (ret < 0) {
		fprintf(stderr, "Error, failed to write to the character device\n");
		return -1;
	}
	
	close(fd);
	
	return 0;
}
