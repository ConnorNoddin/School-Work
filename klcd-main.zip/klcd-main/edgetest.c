#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <sys/types.h>
#include <fcntl.h>
#include <sys/ioctl.h>

#define IOCTL_BASE 0xFACADE /* Magic Number */
#define IOCTL_SUP 0xCAFE /* Command Number */
#define WR_VALUE _IOW(IOCTL_BASE, IOCTL_SUP, int32_t*) /* Ioctl Write Value */

int main(int argc, char *argv[])
{
	int fd, ret, msg_len;
	
	int instruction = 0x02;
	int forwardinst = 0x06;
	
	char *msg;
	
	fd = open("/dev/lcd", O_WRONLY);
	
	if (fd < 0) {
		fprintf(stderr, "Error, failed to open the character device\n");
		return -1;
	}
	
	/* Starts test as position 0 */
	ret = ioctl(fd, WR_VALUE, (int32_t *) &instruction);
	if (ret < 0) {
		fprintf(stderr, "Error, failed to use ioctl on character device\n");
		return -1;
	}
	
	/* Makes sure forward write mode is set*/
	ret = ioctl(fd, WR_VALUE, (int32_t *) &forwardinst);
	if (ret < 0) {
		fprintf(stderr, "Error, failed to use ioctl on character device\n");
		return -1;
	}

	/* Tests zero length */
	msg = "";
	msg_len = strlen(msg);

	ret = write(fd, msg, msg_len);
	if (ret < 0) {
		fprintf(stderr, "Error, failed to write to the character device (this was expected)\n");
		//return -1;
	}
	printf("%d characters wrote. Expected negative value\n", ret);
	
	/* Tests Certain character lengths */
	msg = "I am exactly 32 characters wow!!";
	msg_len = strlen(msg);

	ret = write(fd, msg, msg_len);
	if (ret < 0) {
		fprintf(stderr, "Error, failed to write to the character device\n");
		return -1;
	}
	printf("%d characters wrote. Expected 32 \n", ret);
	
	/* Returns to start */
	ret = ioctl(fd, WR_VALUE, (int32_t *) &instruction);
	if (ret < 0) {
		fprintf(stderr, "Error, failed to use ioctl on character device\n");
		return -1;
	}
	
	/* Tests writing back at beginning */
	msg = "I am WELL over 32 characters lets see what happens!";
	msg_len = strlen(msg);

	ret = write(fd, msg, msg_len);
	if (ret < 0) {
		fprintf(stderr, "Error, failed to write to the character device\n");
		return -1;
	}
	printf("%d characters wrote. Expected 32 \n", ret);
	
	/* Returns to start */
	ret = ioctl(fd, WR_VALUE, (int32_t *) &instruction);
	if (ret < 0) {
		fprintf(stderr, "Error, failed to use ioctl on character device\n");
		return -1;
	}
	
	/* Tests wrapping edge */
	msg = "I am 17 char long";
	msg_len = strlen(msg);

	ret = write(fd, msg, msg_len);
	if (ret < 0) {
		fprintf(stderr, "Error, failed to write to the character device\n");
		return -1;
	}
	printf("%d characters wrote. Expected 17 \n", ret);
	
	close(fd);
	
	return 0;
}
