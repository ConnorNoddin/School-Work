ECE 271 Microcomputer Architecture and Applications
University of Maine
Spring 2022

Name
-----------
```
Connor Noddin
```

Summary of Lab Status
-------
- [X] Pre-lab Assignment (2 points) 
- [X] Basic in-lab assignments (15 points) 
- [X] Something cool (3 points): 

What is your something cool?
-------
I implemented the 1 second delay between the angles using a precise system timer.
I had to change some values as the clock was now running at 8 MHz instead of 4 MHz.

Demo
-------
2.
c)
For 90 degrees, the pulse width was 2.55 ms. For -90 degrees, it was 0.50 ms. For 0 degrees, it was 1.5ms.
This was all verified in lab with the Digilent AD2.

Post-lab Questions
-------
1.
8000000/(1+PSC)=100000
PSC=79
TIMl->PSC = 79;

1=(ARR+1)*1/100000
ARR = 99999
TIMl->ARR = 99999;

0.5 = CCR1/100000
CCR1 = 50000
TIMl->CCRl = 50000;

2.
Using a 8 MHz base clock
PWM period = (ARR + 1)*1/prescaler frequency
8000000/(1+PSC)=prescaler frequency
ARR is a 16 bit value.
PSC is a 16 bit value
8000000/(1+65,535)=122.07 Hz
(65,535 + 1)*1/122.07
This gives 536.87 seconds or about 0.00186 Hz
Then if up and down mode is selected this doubles it,
giving a period of 1073.74 seconds or a frequency of
0.000931 Hz.

Additionally, when we were blinking LEDs in previous labs we were arguably using PWM. One could turn on a GPIO pin
for a second, unplug the STM32, come back in a year, and plug it back in and turn on the GPIO pin for a second.
This would give a PWM signal of a very low frequency.

