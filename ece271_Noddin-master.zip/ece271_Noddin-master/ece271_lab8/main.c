#include <stdint.h>
#include "stm32l476xx.h"
#include "lcd.h"

/*
* Name: Connor Noddin
* Description: Blinks an LED using the system timer
*/


void System_Clock_Init(void);
void SysTick_Initialize(int ticks);
void LED_Pin_Init(void);
void SysTick_Handler(void);
void Delay(uint32_t nTime);
void TIM1_Init(void);
void motor_con(int ang);

volatile int TimeDelay;

int main(void){	
	System_Clock_Init(); //4 Mhz Clock
	LED_Pin_Init();
	
	SysTick_Initialize(3999); //Value calculated in prelab
	
	__asm("CPSIE i");
	
	TIM1_Init();
	
	/* Loop forever */
	while(1){
		motor_con(0); //0 degrees then waits 1 second
		Delay(1000);
		motor_con(90); //90 degrees then waits 1 second
		Delay(1000);
		motor_con(-90); //-90 degrees then waits 1 second
		Delay(1000);
	}
}

void motor_con(int ang) {
	if ((ang > 90) || (ang < -90)) {
		return;
	}
	/* These values are different from the lab writeup and were decided from trial and error */
	switch (ang){
		case 0:
			TIM1->CCR1 = 150; // Change duty cycle of channel 1 outputs
			break;
		case 90:
			TIM1->CCR1 = 255; // Change duty cycle of channel 1 outputs
			break;
		case -90:
			TIM1->CCR1 = 50; // Change duty cycle of channel 1 outputs
			break;
		default:
			TIM1->CCR1 = 150; // Change duty cycle of channel 1 outputs
	}
	
	// Times 2 as the clock is now 4 mhz and not 8
	//Delay(delay_s*2);
}

/* Tests PWM on the LED */
void led_con(void) {
	int i, brightness, stepsize;
	
	brightness = 1;
	stepsize = 1;
	if ((brightness >= 999)||(brightness <= 0 )) {
			stepsize = -stepsize; // Reverse direction
		}
	brightness += stepsize; // Change brightness
	TIM1->CCR1 = brightness; // Change duty cycle of channel 1 outputs
	for(i = 0; i < 1000; i++); // Short delay 
}

void LED_Pin_Init(void){
	RCC->AHB2ENR |= RCC_AHB2ENR_GPIOEEN; //Enables GPIOE clocks
	
	GPIOE->MODER &= 0xFFFCFFFF; //Clears MODER8
	GPIOE->MODER |= 0x00020000; //Sets MODER8 to 10
	
	GPIOE->OTYPER &= 0xFFFFFEFF; //Sets GPIOE to push-pull
	GPIOE->OTYPER |= 0x00000000;
	
	GPIOE->PUPDR &= 0xFFFCFFFF; //Sets Pull-Up/Down registers for GPIO PE8
	GPIOE->PUPDR |= 0x00000000;
	
	// Selects alternate function
	GPIOE->AFR[1] &= ~(0xF); // ARF{l] for pins 8-15
	GPIOE->AFR[1] |= 1UL; // TIMl_CHlN defined as 0l 
}

void System_Clock_Init(void){
	/* Disables the MSI clock */
	RCC->CR &= ~RCC_CR_MSION;
	//RCC->CR |= RCC_CR_	MSIRDY;

	/* Set the MSI range to 6 */
	RCC->CR &= ~RCC_CR_MSIRANGE;
	RCC->CR |= RCC_CR_MSIRANGE_6;

	/* Tells MSI clock to use this new value */
	RCC->CR |= RCC_CR_MSIRGSEL;

	/* Enables the MSI clock */
	RCC->CR |= RCC_CR_MSION;

	/* Waits until ready bit is 1 on MSI clock */
	while (!(RCC->CR & RCC_CR_MSIRDY));
}

void SysTick_Initialize(int ticks) {
	/* Disable SysTick IRQ and SysTick counter */
	SysTick->CTRL = 0;
	
	/* Set reload register */
	SysTick->LOAD = (ticks - 1); 
	
	/* Sets interrupt priority */
	NVIC_SetPriority(SysTick_IRQn, (1<<__NVIC_PRIO_BITS)-1);
	
	/* Sets systick counter value */
	SysTick->VAL = 0;
	
	/* Sets processor clock */
	SysTick->CTRL |= SysTick_CTRL_CLKSOURCE_Msk;
	
	/* Sets Systick exception request */
	SysTick->CTRL |= SysTick_CTRL_TICKINT_Msk;
	
	/* Sets systick timer */
	SysTick->CTRL |= SysTick_CTRL_ENABLE_Msk;
}

/* SysTick interrupt service routine */
void SysTick_Handler(void) { 
	/* TimeDeLay is a global variable declared as volatile */
	if (TimeDelay > 0) { /* Prevent it from being negative */
		TimeDelay--; /* TimeDelay is a global volatile variable */
	}
}

/* nTime: specifies the delay time Length */
void Delay(uint32_t nTime) {
	TimeDelay = nTime; /* TimeDelay must be declared as volatile */
	while(TimeDelay != 0); /* Busy wait */
} 

void TIM1_Init(void){
	// Enable clock on timer 1
	RCC->APB2ENR |= RCC_APB2ENR_TIM1EN;
	// Sets counting direction
	TIM1->CR1 &= ~TIM_CR1_DIR;
	// Prescaler value for clock
	TIM1->PSC = 39; // 100 kHz
	// Sets auto reload
	TIM1->ARR = 1999;

	// Clear compare mode bits
	TIM1->CCMR1 &= ~TIM_CCMR1_OC1M; 
	
	// Selects toggle mode
	TIM1->CCMR1 |= TIM_CCMR1_OC1M_1 | TIM_CCMR1_OC1M_2;
	//Enables preload on output 1
	TIM1->CCMR1 |= TIM_CCMR1_OC1PE;
	// Select output polarity
	TIM1->CCER &= ~TIM_CCER_CC1NP; // Sets active high
	//Enable output for channel 1 complementary output
	TIM1->CCER |= TIM_CCER_CC1NE;
	// Main output enable
	TIM1->BDTR |= TIM_BDTR_MOE;
	// Sets duty cycle to 50%.
	TIM1->CCR1 = 500;
	// Enable timer 1
	TIM1->CR1 |= TIM_CR1_CEN; 

}

