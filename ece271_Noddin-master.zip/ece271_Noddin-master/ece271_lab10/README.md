ECE 271 Microcomputer Architecture and Applications
University of Maine
Spring 2022

Name
-----------
```
Connor Noddin
```

Summary of Lab Status
-------
- [X] Pre-lab Assignment (2 points) 
- [X] Basic in-lab assignments (15 points) 
- [X] Something cool (3 points): 

What is your something cool?
-------
I made the LCD print the ADC value. It updates in real time and has
a relatively fast refresh rate for accurate results.

Demo
-------
Done

Post-lab Questions
-------
1.
a)
ADC1->DR value is 2043 (As close as I could get it)
Voltage is 1.581 Volts on PA1

b)
ADC1->DR is 2043 and val (my variable in the main loop) is 2043

c)

1.581/Vref = 2043/4095
4095*1.581/2043 = Vref
Vref = 3.1689 Volts.
It should be noted that I plugged my poteniometer
into 3V3 instead of 3V as Pascal and I discovered in lab gives
more accurate results