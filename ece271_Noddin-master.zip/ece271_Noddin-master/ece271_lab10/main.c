#include <stdint.h>
#include <stdio.h>
#include "stm32l476xx.h"
#include "lcd.h"

/*
* Name: Connor Noddin
* Description: Utilizes the ADC to measure infared
*/


void System_Clock_Init(void);
void Pin_Init(void);
void ADC_Init(void);
void ADC_Wakeup(void);

volatile int val;

int main(void){	
	
	char str[7];
	
	System_Clock_Init(); //16 Mhz Clock
	Pin_Init();
	ADC_Init();
	
	LCD_Clock_Init();

	LCD_Pin_Init();

	LCD_Configure();

	/* Loop forever */
	while(1) {
		//Starts one AD conversion
		ADC1->CR |= ADC_CR_ADSTART;
		
		//Waits for bit to be set by hardware
		while(!(ADC123_COMMON->CSR & ADC_CSR_EOC_MST));

		//Stores digital value to val
		val = ADC1->DR;
		
		sprintf(str, "%d", val); //Convers int to string for LCD
		
		LCD_Display_String(str); //Prints value of ADC to LCD
		
	}
}

void Pin_Init(void){
	RCC->AHB2ENR |= RCC_AHB2ENR_GPIOAEN; //Enables GPIOA clocks
	
	GPIOA->MODER &= 0xFFFFFFF3; //10 Alternative Function
	GPIOA->MODER |= 0x0000000C;
	
	//GPIOA->OTYPER &= 0xFFFFFFF3; //Sets GPIOEAto push-pull
	//GPIOA->OTYPER |= 0x00000000;
	
	//GPIOA->PUPDR &= 0xFFFFFFF3; //Sets Pull-Up/Down registers for GPIOA
	//GPIOA->PUPDR |= 0x00000000;
	
	GPIOA->ASCR &= 0xFFFD; //Hooks up analog pin to the ADC
	GPIOA->ASCR |= 0x0002;

}

void System_Clock_Init(void){
	/* Enables the HSI clock */
	RCC->CR |= RCC_CR_HSION;
	
	/* Waits until ready bit is 1 on HSI clock */
	while (!(RCC->CR & RCC_CR_HSIRDY));

	/* Set the HSI range */
	RCC->CFGR &= ~RCC_CFGR_SW;
	RCC->CFGR |= RCC_CFGR_SW_HSI;
	
	//Waits for switch status
	while(!(RCC->CFGR & RCC_CFGR_SWS));

}

void ADC_Wakeup(void) {
	int wait_time;
	//Starts ADC operation
	if ((ADC1->CR & ADC_CR_DEEPPWD) == ADC_CR_DEEPPWD) {
			ADC1->CR &= ~ADC_CR_DEEPPWD;
	}

	//Enables voltage regulator
	ADC1->CR |= ADC_CR_ADVREGEN;

	//Waits for voltage regulator to start up
	wait_time = 20 * (80000000 / 1000000);
	while (wait_time != 0) {
		wait_time--;
	}
}

void ADC_Init(void){
	RCC->AHB2ENR |= RCC_AHB2ENR_ADCEN; //Enables ADC clocks

	ADC1->CR &= ~ADC_CR_ADEN; //Disable ADC1

	SYSCFG->CFGR1 |= SYSCFG_CFGR1_BOOSTEN; //Voltage booster

	ADC123_COMMON->CCR |= ADC_CCR_VREFEN; //Enables conversion of internal channels

	ADC123_COMMON->CCR &= ~ADC_CCR_PRESC; //Clock not divided

	ADC123_COMMON->CCR |= ADC_CCR_CKMODE_0; //Synchonrous clock mode

	ADC123_COMMON->CCR &= ~ADC_CCR_DUAL; //Enables conversion of internal channels
	
	ADC_Wakeup(); //Wake up ADC VIA software
	
	ADC1->CFGR &= ~ADC_CFGR_RES; //12 bit resolution 00
	
	ADC1->CFGR &= ~ADC_CFGR_ALIGN; //Sets right alignment

	ADC1->SQR1 &= ~ADC_SQR1_L; //Conversion Sequence
	
	ADC1->SQR1 &= ~ADC_SQR1_SQ1; //Specify channel 6
	
	ADC1->SQR1 |= ( 6U << 6 ); 
	
	ADC1->DIFSEL &= ~ADC_DIFSEL_DIFSEL_6; //Sets channel 6
	
	ADC1->SMPR1 |= ADC_SMPR1_SMP6; //Sets sampling time to 1
	
	ADC1->CFGR &= ~ADC_CFGR_EXTEN; //Software trigger
	
	ADC1->CR |= ADC_CR_ADEN;
	
	while(!(ADC1->ISR & ADC_ISR_ADRDY));
	
}
