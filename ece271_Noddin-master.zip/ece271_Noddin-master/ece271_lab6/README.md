ECE 271 Microcomputer Architecture and Applications
University of Maine
Spring 2022

Name
-----------
```
Connor Noddin
```

Summary of Lab Status
-------
- [X] Pre-lab Assignment (2 points) 
- [X] Basic in-lab assignments (15 points) 
- [X] Something cool (3 points): 

What is your something cool?
-------
My something cool involved redoing what I did for lab 5 but in assembly.
By pressing up on the joystick you can test full stepping.
By pressing down on the joystick you can test half stepping.


Post-lab Questions
-------
1.
The ABI helps our code be more modular and cooperate better with other code. For example, interfacing
with an operating system can be more seamless by following the ABI. If we were to use any register that
we wanted to, then our could would not neccesarily play nice with other code. If we all follow the same
ABI, our could should be able to much more easily be implemented alongside other code.

2.
C places local variables on a stack because this is an efficient method of implementing local variables.
When a subroutine is called, that subroutine may have local variables. These variables should be freed
after the subroutine terminates. A stack allows a variable memory pool that can easily be added to and freed.
The stack can shrink and grow as variables are created and destroyed. Additionally, the stack is often
in the cache which is much faster than RAM. The stack is also memory efficient. A global variable would
persist in memory indefinitely. Meanwhile, stack memory gets dynamically freed and allocated. This
can make the program much more memory efficient.

3.
The binary image for my Lab6 is 10,444 bytes. Meanwhile, the binary image for my Lab5 is 28,560 bytes.
This code, effectively accomplishing the same thing, is less than half the size when programmed in
assembly.