ECE 271 Microcomputer Architecture and Applications
University of Maine
Spring 2022

Name
-----------
```
Connor Noddin
```

Summary of Lab Status
-------
- [X] Pre-lab Assignment (2 points) 
- [X] Basic in-lab assignments (15 points) 
- [X] Something cool (3 points): 

What is your something cool?
-------
I implemented the LED such that it turns on when an object is within 3 inches
and turns off when it is outside of 3 inches.

Demo
-------
Done

Post-lab Questions
-------
1.
The accuracy when measuring the 1Hz square wave was within one percent.
At times I would see a value such as 500600, althought it other times
it would increase to 502000. At all times, it seemed higher than the
expected 500000. Regardless, this is all within spec of the HSI Timer,
which has a 1% accuracy.

2.
Using a tape measure, I placed my hand at 12 inches away from the sensor.
There was a large deviation in sensor values, sometimes going over 13 inches.
However, the value seemed to hover around 12.2 inches. This agrees with my
findings from post lab #1 whereas the result is typically slightly higher
than actual.