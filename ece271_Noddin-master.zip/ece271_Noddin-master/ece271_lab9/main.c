#include <stdint.h>
#include "stm32l476xx.h"
#include "lcd.h"

/*
* Name: Connor Noddin
* Description: Blinks an LED using the system timer
*/


void System_Clock_Init(void);
void Pin_Init(void);
void TIM4_Init(void);
void TIM1_Init(void);

volatile uint32_t pulse_width = 0;
volatile uint32_t last_captured = 0;
volatile uint32_t signal_polarity = 0; // Assume input is Low initially
volatile uint32_t overflow_count = 0;
volatile double inch, cm;

int main(void){	
	int result;

	System_Clock_Init(); //16 Mhz Clock
	Pin_Init();
	TIM4_Init();
	TIM1_Init();
	
		
	/* Loop forever */
	while(1) {
		result = pulse_width;
		inch = result/148.0;
		cm = result/58.0;
		if (inch < 3) {
			GPIOE->ODR |= 0x0100; //Turns on green LED
		}
		GPIOE->ODR &= 0xFEFF;	 //Turns off green LED
			
	}
}

void Pin_Init(void){
	RCC->AHB2ENR |= RCC_AHB2ENR_GPIOBEN; //Enables GPIOB clocks
	RCC->AHB2ENR |= RCC_AHB2ENR_GPIOEEN; //Enables GPIOB clocks
	
	GPIOB->MODER &= 0xFFFFCFFF; //10 Alternative Function
	GPIOB->MODER |= 0x00002000;
	
	GPIOB->PUPDR &= 0xFFFFCFFF; //Sets Pull-Up/Down registers for GPIO PE6
	GPIOB->PUPDR |= 0x00000000;
	
	// Selects alternate function
	GPIOB->AFR[0] &= 0xF0FFFFFF; // ARF[0] for pins 0-7
	GPIOB->AFR[0] |= 0x02000000; // TIM4_CHl defined as 2 
	
	GPIOE->MODER &= 0xFF3FFFFF; //10 Alternative Function
	GPIOE->MODER |= 0x00800000;
	
	GPIOE->PUPDR &= 0xFF3FFFFF; //Sets Pull-Up/Down registers for GPIO PE11
	GPIOE->PUPDR |= 0x00000000;
	
	// Selects alternate function
	GPIOE->AFR[1] &= 0xFFFF0FFF; // ARF[1] for pins 8-15
	GPIOE->AFR[1] |= 0x00001000; // TIM2_CHl defined as 2 
	
	
	GPIOE->MODER &= 0xFFFCFFFF; //Clears MODER8
	GPIOE->MODER |= 0x00010000; //Sets MODER8 to 01
	
	GPIOE->OTYPER &= 0xFFFFFEFF; //Sets GPIOE to push-pull
	GPIOE->OTYPER |= 0x00000000;
	
	GPIOE->PUPDR &= 0xFFFCFFFF; //Sets Pull-Up/Down registers for GPIO PE8
	GPIOE->PUPDR |= 0x00000000;
}

void System_Clock_Init(void){
	/* Enables the HSI clock */
	RCC->CR |= RCC_CR_HSION;
	
	/* Waits until ready bit is 1 on HSI clock */
	while (!(RCC->CR & RCC_CR_HSIRDY));

	/* Set the HSI range */
	RCC->CFGR &= ~RCC_CFGR_SW;
	RCC->CFGR |= RCC_CFGR_SW_HSI;
	
	//Waits for switch status
	while(!(RCC->CFGR & RCC_CFGR_SWS));

}

void TIM1_Init(void){
	// Enable clock on timer 1
	RCC->APB2ENR |= RCC_APB2ENR_TIM1EN;
	// Sets counting direction
	TIM1->CR1 &= ~TIM_CR1_DIR;
	// Prescaler value for clock
	TIM1->PSC = 15; // 100 kHz
	// Sets auto reload
	TIM1->ARR = 65535;

	// Clear compare mode bits
	TIM1->CCMR1 &= ~TIM_CCMR1_OC2M; 
	
	// Selects toggle mode
	TIM1->CCMR1 |= TIM_CCMR1_OC2M_1 | TIM_CCMR1_OC2M_2;
	//Enables preload on output 1
	TIM1->CCMR1 |= TIM_CCMR1_OC2PE;
	// Select output polarity
	TIM1->CCER &= ~TIM_CCER_CC2P; // Sets active high
	//Enable output for channel 1 complementary output
	TIM1->CCER |= TIM_CCER_CC2E;
	// Main output enable
	TIM1->BDTR |= TIM_BDTR_MOE;
	// Sets duty cycle to 10us.
	TIM1->CCR2 = 10;
	// Enable timer 1
	TIM1->CR1 |= TIM_CR1_CEN; 
}

void TIM4_Init(void){
	// Enable clock on timer 1
	RCC->APB1ENR1 |= RCC_APB1ENR1_TIM4EN;
	// Sets counting direction
	TIM1->CR1 &= ~TIM_CR1_DIR;
	// Prescaler value for clock
	TIM4->PSC = 15; // 100 kHz //Maybe 127
	// Sets auto reload
	TIM4->ARR = 0xFFFF;
	
	// Set the direction of channel 1 as input, and select the active input
	TIM4->CCMR1 &= ~TIM_CCMR1_CC1S; //Clear capture/compare 1 selection bits
	TIM4->CCMR1 |= TIM_CCMR1_CC1S_0; // CClS[l:e] for channel 1:

	TIM4->CCMR1 &= ~TIM_CCMR1_IC1F; //No filtering

	TIM4->CCER |= TIM_CCER_CC1P | TIM_CCER_CC1NP; // Both edges generate interrupts
	
	//Input prescaler
	TIM4->CCMR1 &= ~(TIM_CCMR1_IC1PSC); 

	//Enable capture channel
	TIM4->CCER |= TIM_CCER_CC1E;
	
	//Allows interrupts
	TIM4->DIER |= TIM_DIER_CC1IE;
	
	TIM4->DIER |= TIM_DIER_UIE;
	
	//Allow DMA requests
	//TIM4->DIER |= TIM_DIER_CC1DE; // Optional. Required if OMA is used
	
	//Enable timer counter
	TIM4->CR1 |= TIM_CR1_CEN;
	
	//Highest Priority
	NVIC_SetPriority(TIM4_IRQn, 0);
	
	//Enable timer 4 interrupt
	NVIC_EnableIRQ(TIM4_IRQn);
	
}

void TIM4_IRQHandler() {
	uint32_t current_captured;
	
	if((TIM4->SR & TIM_SR_CC1IF) != 0) { // Check interrupt flag is set
		// Reading CCRl clears CClIF interrupt flag
		current_captured = TIM4->CCR1;
		// Toggle the polarity flag;
		signal_polarity= 1 - signal_polarity;
		if (signal_polarity == 0){ // Calculate only when the current input is Low
			pulse_width = current_captured - last_captured + overflow_count*0xFFFF; // Assume up-counting
		} else {
			overflow_count = 0;
		}
		last_captured = current_captured;
	}
	if((TIM4->SR & TIM_SR_UIF) != 0) { // Check if overflow has taken place
		overflow_count = overflow_count + 1;
		TIM4->SR &= ~TIM_SR_UIF; // Clear UIF flag to prevent re-entering
	}
}
