#include <stdint.h>
#include <stdlib.h>
#include <stdio.h>
#include "stm32l476xx.h"
#include "lcd.h"

void System_Clock_Init(void);

int main(void){

	
	int counter = 0; //Sets counter
	char str[6] = "0"; //Sets string to 0

	
	
	System_Clock_Init();

	LCD_Clock_Init();

	LCD_Pin_Init();

	LCD_Configure();

	LCD_Display_Name();
	
	//Sets up joystick
	GPIOA->MODER &= 0xFFFFF300; //Clears, PA0, PA1, PA2, PA3, and PA5
	GPIOA->MODER |= 0x00000000; //Sets PA0, PA1, PA2, PA3, and PA5 to 00
	
	GPIOA->PUPDR &= 0xFFFFF300; //Clears, PA0, PA1, PA2, PA3, and PA5
	GPIOA->PUPDR |= 0x000008AA; //Sets PA0, PA1, PA2, PA3, and PA5 to 10
	

	LCD_Display_String("0");
	
	
	//LCD_Clear();

	/* Loop forever */
	while(1){
		while ((GPIOA->IDR & 0x8) == 0x8){ //Waits for up on joystick
				counter++;
				sprintf(str, "%d", counter); //Adds to counter and displays it
				LCD_Display_String(str);
		}
		while ((GPIOA->IDR & 0x20) == 0x20){ //Waits for down on joystick
				counter--;
				sprintf(str, "%d", counter); //Subtracts from counter and displays it
				LCD_Display_String(str);
		}
	}

}

void System_Clock_Init(void){

	/* Enable the HSI clock */
	RCC->CR |= RCC_CR_HSION;

	/* Wait until HSI is ready */
	while ( (RCC->CR & RCC_CR_HSIRDY) == 0 );

	/* Select HSI as system clock source  */
	RCC->CFGR &= ~RCC_CFGR_SW;
	RCC->CFGR |= RCC_CFGR_SW_HSI;  /* 01: HSI16 oscillator used as system clock */

	/* Wait till HSI is used as system clock source */
	while ((RCC->CFGR & RCC_CFGR_SWS) == 0 );

}


