Connor Noddin
ECE 271
Lab 2

All parts except post lab completed in lab on 1/31/2022


1. If there are 120 display segments, and the duty ratio is 1:4, then there 30 pins for each display segment. Then there are 4 pins for the common plane for a total of 34 pins.

2. The display driver lives on the STM32L476VGT6 according to the user manual.

3. LCD_Ram is 16*32 bit registers of information for a total of 512 bits. There are a maximum of 320 pixels for an LCD.

4. There are 96 pixels in total. Then there are 4 bars on the right side. Bits that aren't hooked up aren't utilized. However, they could eventually be utilized in the future.

5. It prints what was last in the memory. For example, if I print "Connor" then I print "ECE", the output is "ECEnor"