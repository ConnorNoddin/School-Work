Connor Noddin
ECE 271
Lab 2

Readme

If there are 120 display segments, and the duty ratio is 1:4, then there are 120/4 or 30 pins required to drive the LCD.


LCD_Ram is 16*32 bit registers of information for a total of 512 bits

There are 96 pixels in total. Then there are 4 bars on the right side.

It prints what was last there. For example, if I print "Connor" then I print "ECE", the output is "ECEnor"