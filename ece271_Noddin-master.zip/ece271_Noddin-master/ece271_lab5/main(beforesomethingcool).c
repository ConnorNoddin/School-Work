#include <stdint.h>
#include "stm32l476xx.h"
#include "lcd.h"

/*
* Name: Connor Noddin
* Description: Controls a SERVO motor using an STM32
*/

void System_Clock_Init(void);
void Keypad_Pin_Init(void);
void Stepper_Pin_Init(void);
void Stepper_Full_Step(int angle);
void Stepper_Half_Step(int angle);
void full_step_delay(void);
void half_step_delay(void);
void joystick_init(void);
unsigned char keypad_scan(void);

int main(void){

	System_Clock_Init();

	LCD_Clock_Init();

	LCD_Pin_Init();

	LCD_Configure();
	
	Stepper_Pin_Init();
	
	joystick_init();
	
	//Stepper_Full_Step(360); //Tests Full Step
	Stepper_Half_Step(90); //Tests Half Step
	
	/* Loop forever */
	while(1){
		/*
		while ((GPIOA->IDR & 0x8) == 0x8){ //Waits for up on joystick
				Stepper_Half_Step(45); //Tests Half Step
		}
		
		while ((GPIOA->IDR & 0x20) == 0x20){ //Waits for down on joystick
				Stepper_Half_Step(90); //Tests Half Step
		}
		
		while ((GPIOA->IDR & 0x1) == 0x1){
				Stepper_Half_Step(180); //Tests Half Step			
			}
				*/
		
	}

	
}

void Stepper_Full_Step(int angle){
	int k;
	double revs = (angle*256.0/45.0)/4.0; //Determines steps using proportions
	GPIOB->BSRR = (GPIO_BSRR_BR_3 |GPIO_BSRR_BR_6 | GPIO_BSRR_BS_2  | GPIO_BSRR_BS_7 ); //Initial state. 2 high, 3 low, 6 low, 7 high
	full_step_delay();
	for (k = 0; k < revs; k++) { 
		GPIOB->BSRR = (GPIO_BSRR_BR_7 | GPIO_BSRR_BS_6); //2 high, 3 low, 6 high, 7 low
		full_step_delay();
		GPIOB->BSRR = (GPIO_BSRR_BR_2 | GPIO_BSRR_BS_3); //2 low, 3 high, 6 high, 7 low
		full_step_delay();
		GPIOB->BSRR = (GPIO_BSRR_BR_6 | GPIO_BSRR_BS_7); //2 low, 3 high, 6 low, 7 high
		full_step_delay();
		GPIOB->BSRR = (GPIO_BSRR_BR_3 | GPIO_BSRR_BS_2); //2 high, 3 low, 6 low, 7 high
		full_step_delay();
	}

}

void full_step_delay(){
		int i;
		for (i = 0; i < 6000; i++); //Simple delay.
}

void half_step_delay(){
		int i;
		for (i = 0; i < 4000; i++); //Simple delay. 6000 works but is choppy. 4000 is smooth but possibly less stable
}

void joystick_init() {
	RCC->AHB2ENR |= RCC_AHB2ENR_GPIOAEN;
	
	GPIOA->MODER &= 0xFFFFF300; //Clears, PA0, PA1, PA2, PA3, and PA5
	GPIOA->MODER |= 0x00000000; //Sets PA0, PA1, PA2, PA3, and PA5 to 00
	
	GPIOA->PUPDR &= 0xFFFFF300; //Clears, PA0, PA1, PA2, PA3, and PA5
	GPIOA->PUPDR |= 0x000008AA; //Sets PA0, PA1, PA2, PA3, and PA5 to 10
}

void Stepper_Half_Step(int angle){
	int k;
	double revs = (angle*256.0/45.0)/4.0; //Determines steps using proportion
	GPIOB->BSRR = (GPIO_BSRR_BR_3 |GPIO_BSRR_BR_6 | GPIO_BSRR_BS_2  | GPIO_BSRR_BS_7 ); //Initial state. 2 high, 3 low, 6 low, 7 high
	half_step_delay();
	for (k = 0; k < revs; k++) { 
		GPIOB->BSRR = (GPIO_BSRR_BR_7); //7 to low
		half_step_delay();
		GPIOB->BSRR = (GPIO_BSRR_BS_6); //2 low, 3 high, 6 high, 7 low
		half_step_delay();
		GPIOB->BSRR = (GPIO_BSRR_BR_2); //2 low, 3 high, 6 low, 7 high
		half_step_delay();
		GPIOB->BSRR = (GPIO_BSRR_BS_3); //2 high, 3 low, 6 low, 7 high
		half_step_delay();
		GPIOB->BSRR = (GPIO_BSRR_BR_6); //2 high, 3 low, 6 low, 7 high
		half_step_delay();
		GPIOB->BSRR = (GPIO_BSRR_BS_7); //2 high, 3 low, 6 low, 7 high
		half_step_delay();
		GPIOB->BSRR = (GPIO_BSRR_BR_3); //2 high, 3 low, 6 low, 7 high
		half_step_delay();
		GPIOB->BSRR = (GPIO_BSRR_BS_2); //2 high, 3 low, 6 low, 7 high
		half_step_delay();
	}
}

void Stepper_Pin_Init(){
	RCC->AHB2ENR |= RCC_AHB2ENR_GPIOBEN; //Enables clocks on GPIOB
	
	GPIOB->MODER &= 0xFFFF0F0F; //Sets 2, 3, 6, and7 as outputs
	GPIOB->MODER |= 0x00005050;
}

void System_Clock_Init(void){

	/* Enable the HSI clock */
	RCC->CR |= RCC_CR_HSION;

	/* Wait until HSI is ready */
	while ( (RCC->CR & RCC_CR_HSIRDY) == 0 );

	/* Select HSI as system clock source  */
	RCC->CFGR &= ~RCC_CFGR_SW;
	RCC->CFGR |= RCC_CFGR_SW_HSI;  /* 01: HSI16 oscillator used as system clock */

	/* Wait till HSI is used as system clock source */
	while ((RCC->CFGR & RCC_CFGR_SWS) == 0 );

}


