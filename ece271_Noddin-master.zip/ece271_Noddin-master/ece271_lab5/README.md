ECE 271 Microcomputer Architecture and Applications
University of Maine
Spring 2022

Name
-----------
```
Connor Noddin
```

Summary of Lab Status
-------
- [X] Pre-lab Assignment (2 points) 
- [X] Basic in-lab assignments (15 points) 
- [X] Something cool (3 points): 

What is your something cool?
-------
I made a method to compare the smoothness of half stepping vs full stepping on the motor.
Press up on the joystick to test half stepping. Press down on the joystick to test full stepping.
The half stepping should be noticeably smoother.


Post-lab Questions
-------
1.
The darlington array can only supply 500ma of current. If we wanted to increase the amount of current, we
could introduce an external dedicated servo IC. For example, we could use the TMC4671 Servo Controller IC.

2.
It is possible to rotate for motor less than 1/2 step. This is referred to as micro stepping. Micro stepping
can be performed by using pulse-width-modulation (PWM). With PWM you could do values even as small as 1/32 of a 
step. Micro stepping can be useful as it causes the motor to feel much smoother.