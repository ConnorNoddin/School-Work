#include <stdint.h>
#include "stm32l476xx.h"
#include "lcd.h"

/*
* Name: Connor Noddin
* Description: Blinks an LED using the system timer
*/


void System_Clock_Init(void);
void SysTick_Initialize(int ticks);
void LED_Pin_Init(void);
void SysTick_Handler(void);
void Delay(uint32_t nTime);

volatile int TimeDelay;

int main(void){

	System_Clock_Init();
	
	LED_Pin_Init();
	
	SysTick_Initialize(7999); //Value calculated in prelab
	
	__asm("CPSIE i");
	
	/* Loop forever */
	while(1){
		Delay(1000);
		GPIOB->ODR |= 0x0004;  //Turns on red LED 
		Delay(1000);
		GPIOB->ODR &= 0xFFFB;  //Turns off red LED
	}
}

void LED_Pin_Init(){
	RCC->AHB2ENR |= RCC_AHB2ENR_GPIOBEN; //Enables GPIOB clocks
	
	GPIOB->MODER &= 0xFFFFFFCF; //Clears MODER2
	GPIOB->MODER |= 0x00000010; //Sets MODER2 to 01
	
	GPIOB->OTYPER &= 0xFFFFFFFB; //Sets GPIOB to push-pull
	GPIOB->OTYPER |= 0x00000000;
	
	GPIOB->PUPDR &= 0xFFFFFFCF; //Sets Pull-Up/Down registers for GPIO PB2
	GPIOB->PUPDR |= 0x00000000;
}

void System_Clock_Init(void){
	/* Disables the MSI clock */
	RCC->CR &= ~RCC_CR_MSION;
	//RCC->CR |= RCC_CR_	MSIRDY;

	/* Set the MSI range to 7 */
	RCC->CR &= ~RCC_CR_MSIRANGE;
	RCC->CR |= RCC_CR_MSIRANGE_7;

	/* Tells MSI clock to use this new value */
	RCC->CR |= RCC_CR_MSIRGSEL;

	/* Enables the MSI clock */
	RCC->CR |= RCC_CR_MSION;

	/* Waits until ready bit is 1 on MSI clock */
	while (!(RCC->CR & RCC_CR_MSIRDY));
}

void SysTick_Initialize(int ticks) {
	/* Disable SysTick IRQ and SysTick counter */
	SysTick->CTRL = 0;
	
	/* Set reload register */
	SysTick->LOAD = (ticks - 1); 
	
	/* Sets interrupt priority */
	NVIC_SetPriority(SysTick_IRQn, (1<<__NVIC_PRIO_BITS)-1);
	
	/* Sets systick counter value */
	SysTick->VAL = 0;
	
	/* Sets processor clock */
	SysTick->CTRL |= SysTick_CTRL_CLKSOURCE_Msk;
	
	/* Sets Systick exception request */
	SysTick->CTRL |= SysTick_CTRL_TICKINT_Msk;
	
	/* Sets systick timer */
	SysTick->CTRL |= SysTick_CTRL_ENABLE_Msk;
}

/* SysTick interrupt service routine */
void SysTick_Handler(void) { 
	/* TimeDeLay is a global variable declared as volatile */
	if (TimeDelay > 0) { /* Prevent it from being negative */
		TimeDelay--; /* TimeDelay is a global volatile variable */
	}
}

/* nTime: specifies the delay time Length */
void Delay(uint32_t nTime) {
	TimeDelay = nTime; /* TimeDelay must be declared as volatile */
	while(TimeDelay != 0); /* Busy wait */
} 
