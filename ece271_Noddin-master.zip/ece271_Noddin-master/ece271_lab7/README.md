ECE 271 Microcomputer Architecture and Applications
University of Maine
Spring 2022

Name
-----------
```
Connor Noddin
```

Summary of Lab Status
-------
- [X] Pre-lab Assignment (2 points) 
- [X] Basic in-lab assignments (15 points) 
- [X] Something cool (3 points): 

What is your something cool?
-------
I made the LED blink SOS in morse code using a more modular function oriented approach. Can also be adjusted
based off how you want your morse code to "sound".

Demo
-------
2.
b)
The timing is fairly accurate. A slow slew rate was used for the LED output pins which could have affected the output. The period
was 1.9956 seconds which was within 1% of the epected output.

This gives a percent error of 0.22%

Post-lab Questions
-------
1.
The address is 0x0000003C

2.
Timer interval between 2 systick interrupts is
Interval = (RELOAD + 1)x(clock source period)
Therefore the maximum interval = (RELOAD + 1)x(0.0625us)
maximum reload value is 16777215
(16777215+1)x(0.0625x10^-6) = 1.048576 seconds