/* ECE271 Spring 2022 Lab1 Code template */
#include <stdint.h>

#include "stm32l476xx.h"

/*
* Name: Connor Noddin
* Description: Controls 2 LEDs using an STM32
*/


void System_Clock_Init(void) {

	/* Enable the high-speed system clock */
	/* You probably shouldn't touch this */
	RCC->CR |= ((uint32_t)RCC_CR_HSION);

	while((RCC->CR & (uint32_t) RCC_CR_HSIRDY)==0) ;

	RCC->CFGR&=(uint32_t)((uint32_t)~(RCC_CFGR_SW));
	RCC->CFGR|=(uint32_t)RCC_CFGR_SW_HSI;

	while ((RCC->CFGR & (uint32_t)RCC_CFGR_SWS)==0) ;
}

int main(void){
	
	int i = 0;
	int num = 0;
	int n = 0;
	int counter = 0;

	/* Initialize the system clock */
	System_Clock_Init();

	/* Your code goes here */
		
	RCC->AHB2ENR &= 0x000000000; //Clears and sets clocks for GPIOA, B, and E
	RCC->AHB2ENR |= 0x00000013;
	
	GPIOB->MODER &= 0xFFFFFFCF; //Clears MODER2
	GPIOB->MODER |= 0x00000010; //Sets MODER2 to 01
	
	GPIOE->MODER &= 0xFFFCFFFF; //Clears MODER8
	GPIOE->MODER |= 0x00010000; //Sets MODER8 to 01
	
	GPIOB->OTYPER &= 0xFFFFFFFB; //Sets GPIOB to push-pull
	GPIOB->OTYPER |= 0x00000000;
	
	GPIOE->OTYPER &= 0xFFFFFEFF; //Sets GPIOE to push-pull
	GPIOE->OTYPER |= 0x00000000;
	
	GPIOB->PUPDR &= 0xFFFFFFCF; //Sets Pull-Up/Down registers for GPIO PB2
	GPIOB->PUPDR |= 0x00000000;
	
	GPIOE->PUPDR &= 0xFFFCFFFF; //Sets Pull-Up/Down registers for GPIO PE8
	GPIOE->PUPDR |= 0x00000000;
	
	GPIOA->MODER &= 0xFFFFF300; //Clears, PA0, PA1, PA2, PA3, and PA5
	GPIOA->MODER |= 0x00000000; //Sets PA0, PA1, PA2, PA3, and PA5 to 00
	
	GPIOA->PUPDR &= 0xFFFFF300; //Clears, PA0, PA1, PA2, PA3, and PA5
	GPIOA->PUPDR |= 0x000008AA; //Sets PA0, PA1, PA2, PA3, and PA5 to 10
	


	//Blinks leds back and forth when holding the center button
	while(1) {
			while ((GPIOA->IDR & 0x1) == 0x1)		//Waits to unpress button. Must click button	
			{
				if (i%2 == 0)
				{
					GPIOB->ODR |= 0x0004; //Turns on red LED
					for (num = 0; num < 1000000; num++) n=0;
					GPIOB->ODR &= 0xFFFB;
				}
				else if (i%2 == 1)
				{
					GPIOE->ODR |= 0x0100; //Turns on green LED
					for (num = 0; num < 1000000; num++) n=0;
					GPIOE->ODR &= 0xFEFF;		
				}
				i++;
			} 
	}

	return 0;
}
