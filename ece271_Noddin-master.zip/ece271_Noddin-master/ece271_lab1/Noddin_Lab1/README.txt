Lab Demo
1. Push-pull allows a pin to supply and absorb current. Open drain, by contrast, and only absorb current. A push-pull configuration can light up and LED by itself. An open drain configuration requires
an outside voltage source.

2.GPIO output speed is referred to as the slew rate. This refers to the voltage over time of a rising of falling edge of a voltage change. The STM32 has 4 speeds, 00, 01, 10, 11 being low, medium, fast, and high speeds
respectively. For this particularly lab you would likely notice little different in the different output speed. The only way you would likely notice it would be by hooking up an oscilloscope for part C. The default speed is low
as this is perfectly acceptable for many applications and reduces power draw. Additionally, there are other benefits of low speed such as reducing EMI.

Post-Lab

1. When a physical swich turns on, the connections on it have the potential to bounce on and off of eachother multiple times in rapid succession. This could be interpreted as the state being changed rapidly and multiple
times which was not the user's intention. This can be solved via hardware or software. One method can be by using a debouncing circuit. A simple debouncing circuit can be made by using a resistor and capacitor. It does this
by having the capacitor be wired in parralel with the switch or button. When the button is pressed, the capacitor discharges. Since it takes time for the capacitor to recharge, it isn't able to pull the processor
pin to low if the connections mechanically rebound.

2. Software debouncing is another way to solve the same problem. A simple way of doing this is the "wait and see" method. Here, the program initially detectes if a switch is closed. Then, it sets a timer for a short period of time
such as 50 ms. IF the switch is still closed after that period of time, it determines that the switch is actually closed and to accept the input. It doesn't actually read that the switch is closed until after this 50 ms period.
A counter debouncer can also be used. Here, the software polls the button or switch on a much shorter interval. If the software can poll consecutive readings, it can then report the button has been pressed. This is a more
statisical approach to solving the problem. However, it is much better for high speed applications.

3. The low GPIO speed is recommended for controlling LEDs. Higher slew rates can cause increased electromagnetic interferance. This is apparent if you do the fourier series of the desired signal as it will take many
more harmonics to achieve the desired result. For a perfect right angle, an exceptionally high (even infinite, theoretically) level of harmonics are required. This results in extremely high frequencies that can cause neighboring circuits
to malfunction. Additionally, these high frequencies and increased number of harmonics increase power draw. A slower slew rate is much easier to aproximate with less harmonics. LEDs, especially since our eyes can struggle to
detect very fast changes, are perfectly fine to use with a low GPIO output speed. Other than wasting power, if a person doesn't have a high speed camera or oscilloscope may never notice a change from a low 00 to a fast 11
slew rate.

