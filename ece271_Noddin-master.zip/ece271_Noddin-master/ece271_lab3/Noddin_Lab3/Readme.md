Lab Demo

2.
a) All key presses show up on the display except for #. This is as # is not defined in LCD.c
b) There are many ways to debounce keypresses. There are hardware and software methods. In my program,
I wait for 4 consecutive readings of the same key press before I register it.
c) My key scan algorithm first checks to see that the user has entered a key press. Then, it compares
differences in GPIO IDR to determine what column has been pressed. Then, it writes to GPIOE ODR in a specific sequence.
Depending on the sequence, it will set GPIOA IDR to a different value. If this happens, the row sequence that caused this effect
is the row. Then it is simply matching the row and column to a structure containing the row, column, and character mappings for this specific 
keypad.
d) We use the external pull up resistor as it will be much stronger than the internal one. The 2.2k ohm resisitors used
are better suited for this application.

Postlab

1. My program can not handle if multiple keys are pressed at once. This is as it looks for specific values such as 0111.
Having 2 keys pressed might return a value such as 0011 which my program would reject. Combination of keys can therefore result in errors.
For example, on my program if I hold down the "2" and "3" keys at the same time it displays a 1. My program does not have code in place to handle
if 2 rows are held down. If one row but two columns are held down, there are errors in the way I process it.