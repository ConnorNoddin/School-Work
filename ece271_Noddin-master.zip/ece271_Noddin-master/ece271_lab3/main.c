#include <stdint.h>
#include <stdio.h>
#include "stm32l476xx.h"
#include "lcd.h"

/*
* Name: Connor Noddin
* Description: Controls a keypad with an STM32
*/

void System_Clock_Init(void);
void Keypad_Pin_Init(void);
unsigned char keypad_scan(void);

int main(void){

	char str[7];
	unsigned char key;
	int i = 0;
	
	System_Clock_Init();

	LCD_Clock_Init();

	LCD_Pin_Init();

	LCD_Configure();
		
	Keypad_Pin_Init();

	str[6] = '\0'; //Sets end of string
  for (i = 0; i < 6; i++) str[i] = ' '; //Preallocates array for moving
	
	//LCD_Clear();
	
	/* Loop forever */
	while(1){
		key = keypad_scan();	 //Includes debounce
		switch (key) {
			case 0xFF: //Displays same string if no key is pressed
				LCD_Display_String(str);
				break;
			case '*': //Clears screen if * is input
				for (i = 0; i < 6; i++)
					str[i]= ' '; //Places characters right to left
				LCD_Display_String(str);
				break;
			case '#': //Repeats previous character
				for (i = 1; i < 6; i++)
						str[i-1] = str[i]; //Places characters right to left
				str[5] = str[4];
				LCD_Display_String(str);
				break;
			default: //Loops through up to 6 characters
					for (i = 1; i < 6; i++)
						str[i-1] = str[i]; //Places characters right to left
					str[5] = key;
					LCD_Display_String(str);
		}
	}
}

unsigned char keypad_scan(void) {
	
	unsigned char key_map [4][4] = {
		{'1', '2', '3', 'A'}, // 1st row
		{'4', '5', '6', 'B'}, // 2nd row
		{'7', '8', '9', 'C'}, // 3rd row
		{'*', '0', '#', 'D'}, // 4th row
	};
	
	int delay = 0, counter = 0, i;
	
	unsigned char row, ColumnPressed, col;
	
	GPIOE->ODR &= 0xFFFFC3FF;
	GPIOE->ODR |= 0x0000;
	//GPIOE->ODR &= 0xA3FF;
	//GPIOE->ODR |= 0x3A00;
	
	if ((GPIOA->IDR & 0x002E) == 0x002E) //No key is pressed
		return 0xFF;
	
	col = 4;
	
	//Debouncing, waits for 4 consecutive readings
	for(i = 0; i < 10; i++) {
		for (delay = 0; delay < 20000; delay++); //Delay, helps with debouncing
		//Identifies Key Column Being Pressed
		if ((GPIOA->IDR & 0x002E) == 0x000E) //Identifies if column 3 is pressed
			ColumnPressed = 3;
		else if ((GPIOA->IDR & 0x002E) == 0x0026) //Identifies if column 2 is pressed
			ColumnPressed = 2;
		else if ((GPIOA->IDR & 0x002E) == 0x002A) //Identifies if column 1 is pressed
			ColumnPressed = 1;
		else if ((GPIOA->IDR & 0x002E) == 0x002C) //Identifies if column 0 is pressed
			ColumnPressed = 0;
		if ((GPIOA->IDR & 0x002E) == 0x002E) {
			counter = 0; 
		} else {
			counter++;
			if (counter >= 4)
				col = ColumnPressed;
			}
	}
	
	//Returns nothing if 4 consecutive readings could not be met
	if (col == 4)
		return 0xFF;
	
	//Identifies row being pressed
	for(row = 0; row < 4 ; row++) {
		if (row == 0){ //Sets first row
			GPIOE->ODR &= 0xFFFFC3FF;
			GPIOE->ODR |= (GPIO_ODR_ODR_13 | GPIO_ODR_ODR_12 | GPIO_ODR_ODR_11);
			for (delay = 0; delay < 200000; delay++);
			if ((GPIOA->IDR & 0x002E) != 0x002E) return key_map[0][col];
		}
		//1100001111111111, 0011010000000000
		if (row == 1){ //Sets second row
			GPIOE->ODR &= 0xFFFFC3FF;
			GPIOE->ODR |= (GPIO_ODR_ODR_13 | GPIO_ODR_ODR_12 | GPIO_ODR_ODR_10);
			for (delay = 0; delay < 200000; delay++);
			if ((GPIOA->IDR & 0x002E) != 0x002E) return key_map[1][col];
		}
		
		//1100001111111111, 0010110000000000
		if (row == 2){ //Sets third row
			GPIOE->ODR &= 0xFFFFC3FF;
			GPIOE->ODR |= (GPIO_ODR_ODR_13 | GPIO_ODR_ODR_11 | GPIO_ODR_ODR_10);
			for (delay = 0; delay < 200000; delay++);
			if ((GPIOA->IDR & 0x002E) != 0x002E) return key_map[2][col];
		}
		if (row == 3){ //Sets fourth row
			//1100001111111111, 0001110000000000
			GPIOE->ODR &= 0xFFFFC3FF; //Sets row
			GPIOE->ODR |= (GPIO_ODR_ODR_12 | GPIO_ODR_ODR_11 | GPIO_ODR_ODR_10);
			for (delay = 0; delay < 200000; delay++);
			if ((GPIOA->IDR & 0x002E) != 0x002E) return key_map[3][col];		
		}
	}
	return 0xFF;
}

void Keypad_Pin_Init(void) {
	RCC->AHB2ENR |= RCC_AHB2ENR_GPIOEEN; //Enables clocks on GPIOA and GPIOE
	RCC->AHB2ENR |= RCC_AHB2ENR_GPIOAEN;
	
	GPIOA->MODER &= 0xFFFFF303; //Sets gpio a pins
	GPIOA->MODER |= 0x00000000;
	
	GPIOE->MODER &= 0xF00FFFFF; //Sets gpio e pins
	GPIOE->MODER |= 0x05500000;
}

void System_Clock_Init(void){

	/* Enable the HSI clock */
	RCC->CR |= RCC_CR_HSION;

	/* Wait until HSI is ready */
	while ( (RCC->CR & RCC_CR_HSIRDY) == 0 );

	/* Select HSI as system clock source  */
	RCC->CFGR &= ~RCC_CFGR_SW;
	RCC->CFGR |= RCC_CFGR_SW_HSI;  /* 01: HSI16 oscillator used as system clock */

	/* Wait till HSI is used as system clock source */
	while ((RCC->CFGR & RCC_CFGR_SWS) == 0 );

}


