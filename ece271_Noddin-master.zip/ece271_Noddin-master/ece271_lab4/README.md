ECE 271 Microcomputer Architecture and Applications
University of Maine
Spring 2022

Name
-----------
```
Connor Noddin
```

Summary of Lab Status
-------
- [X] Pre-lab Assignment (2 points) 
- [X] Basic in-lab assignments (15 points) 
- [X] Something cool (3 points): 

What is your something cool?
-------
My something cool involved implementing a sleep function in Assembly and using this to flash the LEDs.
My sleep function is very cool in that it is scalable to large numbers, breaking free from certain bit 
number limitations.


Post-lab Questions
-------
1.
example: BIC r0, r1, #0xab
The BIC insruction is the bit clear instruction. It performs an AND
operation on the bits in R1 with the complements of the bits in
the operand, #0xab. It combines 2 logical operations into one. It is
similar to A AND ~B. Therefore, this instruction is not really necessary.
However, it can make code smaller and more efficient. You can simply AND
with the negated operand if BIC did not exist.

2.
The CMP instruction compares two operands to see if they are
equal or not and sets flags accordingly. The SUB instruction substracts
an operand from another operand and saves it. CMP works by subtracting two operands
from eachother, however the answer is not saved. While what the two instructions
do is similar, the results they produce is very different.