ECE 271 Microcomputer Architecture and Applications
University of Maine
Spring 2022

Name
-----------
```
Connor Noddin
```

Summary of Lab Status
-------
- [X] Pre-lab Assignment (2 points) 
- [X] Basic in-lab assignments (15 points) 
- [X] Something cool (3 points): 

What is your something cool?
-------
I used the speaker and played twinkle twinkle little star. We both
agreed it sounded pretty good. The table associated with it is located in
sine_table.h

Demo
-------
Done

Post-lab Questions
-------
1.
Using my PSC and ARR
step = 360/(44087/293.665)
This gives a step size of 2.397

2.
The sin function could be called many, many times a second. This would result in very slow code.
Additionally, this context switching (from the interrupt handler to the math function)
will make the interrupt much slower. As interrupts are generally disabled (except higher priority
interrupts) while in an interrupt handler, it is best to keep these functions short and fast.
