#include <stdint.h>
#include <stdio.h>
#include "stm32l476xx.h"
#include "lcd.h"
#include "sine_table.h"

/*
* Name: Connor Noddin
* Description: Utilizes the DAC to make audio
*/

void System_Clock_Init(void);
void DAC_Channel2_Init(void);
void Pin_Init(void);
void TIM4_Init(void);
int lookup_sine(int angle);

volatile int current_angle = 0;
volatile int add = 0;

int main(void){	
	int i, k;
	int note;
	System_Clock_Init();
	DAC_Channel2_Init();
	Pin_Init();
	TIM4_Init();
	

	/* Loop forever */
	while(1) {
		// Use add = 3590 for a 440 Hz sine wave
		for (k = 0; k < NOTES; k++) {
			note = twinkle_freq[k];
			add = 1000*(360.0/(44087.0/note));
			// SPEED OF SONG
			for (i = 0; i < twinkle_len[k] * 700000; i++);
			add = 0;
			for (i = 0; i < 100000; i++);
		}
	}
}

void Pin_Init(void){
	RCC->AHB2ENR |= RCC_AHB2ENR_GPIOAEN; //Enables GPIOA clocks
	
	GPIOA->MODER &= 0xFFFFF3FF; //11 Analogue
	GPIOA->MODER |= 0x00000C00;
	
	//GPIOA->OTYPER &= 0xFFFFFFF3; //Sets GPIOEAto push-pull
	//GPIOA->OTYPER |= 0x00000000;
	
	//GPIOA->PUPDR &= 0xFFFFFFF3; //Sets Pull-Up/Down registers for GPIOA
	//GPIOA->PUPDR |= 0x00000000;
	
	//GPIOA->ASCR &= 0xFFFD; //Hooks up analog pin to the ADC
	//GPIOA->ASCR |= 0x0002;

}

void System_Clock_Init(void){
	/* Enables the HSI clock */
	RCC->CR |= RCC_CR_HSION;
	
	/* Waits until ready bit is 1 on HSI clock */
	while (!(RCC->CR & RCC_CR_HSIRDY));

	/* Set the HSI range */
	RCC->CFGR &= ~RCC_CFGR_SW;
	RCC->CFGR |= RCC_CFGR_SW_HSI;
	
	//Waits for switch status
	while(!(RCC->CFGR & RCC_CFGR_SWS));

}

int lookup_sine(int angle){
	int x;
	x = angle%360;
	if (x < 90) return sine_lookup[x];
	if (x < 180) return sine_lookup[180-x];
	if (x < 270) return 4096 - sine_lookup[x-180];
	
	return (4096 - sine_lookup[360-x]);
}

void DAC_Channel2_Init(void){
	//Enables DAC clocks
	RCC->APB1ENR1 |= RCC_APB1ENR1_DAC1EN;
	
	//Disables DACs
	DAC->CR &= ~DAC_CR_EN1;
	DAC->CR &= ~DAC_CR_EN2;
	
	//Sets to external pin with buffer enabled
	DAC->MCR &= ~DAC_MCR_MODE2;
	
	//Selects software triggering
	DAC->CR &= ~DAC_CR_TSEL2;
	DAC->CR |= DAC_CR_TSEL2_0;
	DAC->CR |= DAC_CR_TSEL2_2;
	
	//Enables the DAC
	DAC->CR |= DAC_CR_EN2;
	
	//Then call GPIOA function
	
}

void TIM4_Init(void){
	// Enable clock on timer 1
	RCC->APB1ENR1 |= RCC_APB1ENR1_TIM4EN;
	// Sets edge-aligned mode
	TIM4->CR1 &= ~TIM_CR1_CMS;
	
	// Sets output trigger
	TIM4->CR2 &= ~TIM_CR2_MMS;
	TIM4->CR2 |= 0x40;
	
	//Allows interrupts
	TIM4->DIER |= TIM_DIER_TIE;
	
	TIM4->DIER |= TIM_DIER_UIE;
	
	// Sets PWM mode 1
	TIM4->CCMR1 &= ~TIM_CCMR1_OC1M;
	TIM4->CCMR1 |= (TIM_CCMR1_OC1M_1 | TIM_CCMR1_OC1M_2);
	
	// Prescaler value for clock
	TIM4->PSC = 10; // 44077 Hz
	// Sets auto reload
	TIM4->ARR = 32;
	
	//50% Duty Cycle
	TIM4->CCR1 = 16;
	
	TIM4->CCER |= TIM_CCER_CC1E;
	
	//Allow DMA requests
	//TIM4->DIER |= TIM_DIER_CC1DE; // Optional. Required if OMA is used
	
	//Enable timer counter
	TIM4->CR1 |= TIM_CR1_CEN;
	
	//Highest Priority
	NVIC_SetPriority(TIM4_IRQn, 0);
	
	//Enable timer 4 interrupt
	NVIC_EnableIRQ(TIM4_IRQn);
	
}

void TIM4_IRQHandler() {
	
	if((TIM4->SR & TIM_SR_CC1IF) != 0) { // Check interrupt flag is set
		DAC->DHR12R2 = lookup_sine(current_angle/1000);
		current_angle = current_angle + add;
		if (current_angle > 360*1000) current_angle = 0;
		TIM4->SR &= ~TIM_SR_CC1IF;
	}
	if((TIM4->SR & TIM_SR_UIF) != 0) { // Check if overflow has taken place
		TIM4->SR &= ~TIM_SR_UIF; // Clear UIF flag to prevent re-entering
	}
	return;
}

