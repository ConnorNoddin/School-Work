ECE 331 S21 Kernel Driver Project

See the project description for details on wiring and GPIO pins used.

***** DO NOT COMMIT IN THIS PROJECT *****
