// A. Sheaff 2/23/2022
// LCD Driver
#ifndef LCD_H
#define LCD_H

#include <linux/types.h>
#include <asm/ioctl.h>
#define FOUR_BIT 0
#define EIGHT_BIT 1
#define EIGHT_FUNCT_SET 0x003
#define FOUR_FUNCT_SET 0X002
#define INTERFACE_FUNCT_SET 0x028
#define DISP_OFF 0x008
#define CLR_DISP 0x001
#define ENTRY_SET 0x006
#define DISP_ON 0x00F
#define SET_DD_ADD 0x080
#define CHAR_E 0x145
#define CHAR_C 0x143
#define CHAR_SPACE 0x120
#define CHAR_3 0x133
#define CHAR_1 0x131

#endif	// LCD_H
