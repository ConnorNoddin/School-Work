#include <stdio.h>
#include <string.h>
#include "dictionary.h"

/*
* Description: Testing for dictionary.c. Tests
* all functions multiple ways including edge cases.
* Helps check for expected outputs
*/ 
int main(int argc, char *argv[]) {
    
    /*Tests 4 different dictionarys at once, also tests init function */
    Dictionary *my_dict0 = dictionary_init();
    Dictionary *my_dict1 = dictionary_init();
    Dictionary *my_dict2 = dictionary_init();
    Dictionary *my_dict3 = dictionary_init();
    
    /* Tests dictionary with multiple objects */
    dictionary_add(my_dict0, "Key0", "Value0");
    dictionary_add(my_dict0, "Key1", "Value1");
    dictionary_add(my_dict0, "Key2", "Value2");
    dictionary_add(my_dict0, "Key3", "Value3");
    dictionary_add(my_dict0, "Key4", "Value4");
    
    /* Tests dictionary with single object */
    dictionary_add(my_dict1, "Key0", "Value0");
    
    /* Tests dictionary with single empty object */
    dictionary_add(my_dict2, "Key0", "");
    
    /* Tests dictionary with no objects */
    
    /* Tests print for all cases */
    dictionary_print(my_dict0);
    dictionary_print(my_dict1);
    dictionary_print(my_dict2);
    dictionary_print(my_dict3);
    
    /* Tests remove function on all cases */
    dictionary_remove(my_dict0, "Key0");
    dictionary_remove(my_dict0, "Key3");
    dictionary_remove(my_dict0, "Key4");
    
    dictionary_remove(my_dict1, "Key0");
    
    dictionary_remove(my_dict2, "Key0");
    
    dictionary_remove(my_dict3, "Key0");
    
    dictionary_print(my_dict0);
    dictionary_print(my_dict1);
    dictionary_print(my_dict2);
    dictionary_print(my_dict3);
    
    /* Tests value function on all cases */
    dictionary_add(my_dict1, "Key0", "Value0");
    printf("Dictionary 0 key0 value is: %s\n", dictionary_value(my_dict0, "Key0"));
    printf("Dictionary 0 key1 value is: %s\n", dictionary_value(my_dict0, "Key1"));
    printf("Dictionary 0 key2 value is: %s\n", dictionary_value(my_dict0, "Key2"));
    printf("Dictionary 1 key0 value is: %s\n", dictionary_value(my_dict1, "Key0"));
    printf("Dictionary 2 key0 value is: %s\n", dictionary_value(my_dict2, "Key0"));
    printf("Dictionary 2 null value is: %s\n", dictionary_value(my_dict2, ""));
    printf("Dictionary 3 key0 value is: %s\n", dictionary_value(my_dict3, "key0"));
    
    /* Tests if duplicate keys updates new value */
    dictionary_add(my_dict0, "Key1", "Value1NEW");
    dictionary_add(my_dict0, "Key2", "Value2NEW");
    dictionary_add(my_dict0, "Key3", "Value3NEW");
    dictionary_add(my_dict0, "Key4", "Value4NEW");
    
    dictionary_print(my_dict0);
    
    /* Tests destroy function on all cases */
    dictionary_destroy(my_dict0);
    dictionary_destroy(my_dict1);
    dictionary_destroy(my_dict2);
    dictionary_destroy(my_dict3);
    
    /* Tries again on dictionary 0 */
    my_dict0 = dictionary_init();
    dictionary_add(my_dict0, "Key0", "Value0");
    dictionary_add(my_dict0, "Key1", "Value1");
    dictionary_add(my_dict0, "Key2", "Value2");
    dictionary_add(my_dict0, "Key3", "Value3");
    dictionary_add(my_dict0, "Key4", "Value4");
    dictionary_print(my_dict0);
    dictionary_destroy(my_dict0);

    return 0;
}
