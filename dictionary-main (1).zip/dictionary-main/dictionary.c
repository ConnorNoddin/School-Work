#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "dictionary.h"

/*
* Description: Mallocs memory for a dictionary object, checking for failures
* Sets default values for dictionary object. To help interfacing
* with other dictionary functions
*/
Dictionary* dictionary_init(void) {
    /* Allocates memory for dictionary */
    Dictionary *new_dict = (Dictionary*) malloc(sizeof(Dictionary));
    if (new_dict == NULL) {
        fprintf(stderr, "Error, malloc failed\n");
        return NULL;
    }
    /* Sets default values */
    new_dict->prev = NULL;
    new_dict->next = NULL;
    new_dict->key = '\0';
    new_dict->value = '\0';
    return new_dict;
}

/*
* Description: Checks if user entered valid key. If key already exists,
* updates the value. Allows empty values. Mallocs() space for key and 
* value strings as well as the new dictionary object. Appends new dictionary
* object to the input dictionary.
*/
Dictionary* dictionary_add(Dictionary *dict, char *key, char *value){
    if (strlen(key) == 0) {
        fprintf(stderr, "Error, the key is empty\n");
        return dict;
    }
    dictionary_remove(dict, key); /* Makes sure there are no duplicate keys. If there is, updates */
    Dictionary *new_dict = dictionary_init(); /* Allocates memory for new dictionary */
    Dictionary *last = dict; /* Sets pointer to dict */
    
    /* Allocates memory for the new key. Inserts new key and value */ 
    new_dict->key = malloc(strlen(key)+1);
    if (new_dict->key == NULL) {
        fprintf(stderr, "Error, malloc failed\n");
        free(new_dict);
        return NULL;
    }
    strcpy(new_dict->key, key);
    new_dict->value = malloc(strlen(value)+1);
    if (new_dict->value == NULL) {
        fprintf(stderr, "Error, malloc failed\n");
        free(new_dict->key);
        free(new_dict);
        return NULL;
    }
    strcpy(new_dict->value, value);

    new_dict->next = NULL; /* Next has to be null as this is the newest node of the dictionary */
 
    /* Checks if the dictionary was empty */
    if (last->next == NULL) {
        last->next = new_dict; /* dict's next link is now the new dictionary */
        new_dict->prev = last; /* The new dictionary's previous link is now the first and empty dictionary object */
        return dict;
    }
 
    /* If dictionary is not empty */
    while (last->next != NULL)
        last = last->next;
 
    /* Appends ot the dictionary then makes the old dict the previous of the last */
    last->next = new_dict;
    new_dict->prev = last;
 
    return dict;
}

/*
* Description: Checks if key is valid. Then loops through 
* each node in the dictionary looking for a matching key. 
* If a matching key is found, prints the value associated with the key.
*/
char* dictionary_value(Dictionary *dict, char *key){
    if (strlen(key) == 0) {
        fprintf(stderr, "Error, the key is empty\n");
        return NULL;
    }
    Dictionary *tmp = dict;
    while (tmp != NULL) { /* Scans until the end of the dictionary */
        if (tmp->prev != NULL) { /* Does not check first and empty dictionary object. Helps with bugs */
            if (strcmp(tmp->key, key) == 0) { /* Checks if string keys are equal */
                return tmp->value; /* Returns matching pair */
            }
        }    
        tmp = tmp->next;
    }
    return NULL; /* Returns NULL if not found */
}

/*
* Description: Loops through each node in the dictionary, 
* looking for a matching key. When a matching key is found, removes the 
* associated dictionary object from the doubly linked list. Then frees
* the memory associated with that dictionary object.
*/
Dictionary* dictionary_remove(Dictionary *dict, char *key){
    if (strlen(key) == 0) {
        fprintf(stderr, "Error, the key is empty\n");
        return dict;
    }
    Dictionary *tmp = dict;
    while (tmp != NULL) { /* Scans from beginning to end of dictionary */
        if (tmp->prev != NULL) { /* Does not consider first and empty dictionary object */
            if (strcmp(tmp->key, key) == 0) { /* Checks if string keys are equal */
                tmp->prev->next = tmp->next; /* Fills in gap where remove was left behind */
                if (tmp->next != NULL) { /* Does not seg fault if last item is removed */
                    tmp->next->prev = tmp->prev;
                }
                free(tmp->key); /* Frees memory associate with node */
                free(tmp->value);
                free(tmp);
                return dict;
            }
        }    
        tmp = tmp->next;
    }
    return dict;
}

/*
* Description: Loops through each node in the dictionary,
* freeing memory that was allocated previously with
* malloc() on each iteration.
*/
Dictionary* dictionary_destroy(Dictionary *dict){
    Dictionary *tmp;
    /* Goes to end of dictionary */
    while (dict != NULL) {
        tmp = dict;
        dict = dict->next;
        free(tmp->key);
        free(tmp->value);
        free(tmp);
    }
    dict = NULL;
    return dict; /* Retuns null pointer to a dictionary object afterwards */
}

/*
* Description: Loops through each node in the dictionary,
* prints data associated with each dictionary object
* on each iteration.
*/
void dictionary_print(Dictionary *dict){
    int count = 0;
    Dictionary *tmp = dict;
    while (tmp != NULL) { /* Scans from beginning to end of dictionary */
        if (tmp->prev != NULL) { /* Does not print first and empty dictionary object */
            printf("Dictionary node: %d \n", count);
            printf("Key: %s, Value: %s\n", tmp->key, tmp->value); /* Prints key and value */
            printf("Prev: %p, Next: %p\n", (void*) tmp->prev, (void*) tmp->next); /* Prints prev and next pointers */
            count++;
        }    
        tmp = tmp->next;
    }
}
