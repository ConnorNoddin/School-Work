#ifndef dictionary_H_  //Guard
#define dictionary_H_

/* Defines _dictionary structure */
typedef struct _dictionary {
    char *key;
    char *value;
    struct _dictionary *next;
    struct _dictionary *prev;
} Dictionary;

Dictionary* dictionary_init(void);

Dictionary* dictionary_add(Dictionary *dict, char *key, char *value);

char* dictionary_value(Dictionary *dict, char *key);

Dictionary* dictionary_remove(Dictionary *dict, char *key);

Dictionary* dictionary_destroy(Dictionary *dict);

void dictionary_print(Dictionary *dict);

#endif // dictionary_H_
