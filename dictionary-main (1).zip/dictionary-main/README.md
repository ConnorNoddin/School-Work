# Dictionary ECE 331 Spring 2022 Project 01

## Authors
Connor Noddin

## Install
Extract files to desired directory. Run make command.
Run "main" to test dictionary object.

## Usage
### dictionary_init()
Use this function to initialize an empty dictionary object. This function gets passed no arguments. This function will
return a pointer to the first and empty key value pair.

### dictionary_add()
This function adds a new key value pair to the dictionary. Pass the function a pointer to your dictionary object, the unique key value (string), and the value (string) for the new entry. If the key value already exists in your dictionary, it will update it with the new one. This function will return a pointer to the first and empty key value pair.

### dictionary_value()
This function returns a value (string) associated with a passed key. This function is passed a pointer to a dictionary object and a key value (string). It will return a pointer to the value (string) associated with the key that was passed as an argument.

### dictionary_remove()
This function removes a value (string) and key (string) associated with a key. This function is passed a pointer to a dictionary object and a key value (string). It returns a pointer to the first and empty dictionary key-value pair. If the first entry is removed, the return value is the new first and empty key value pair.

### dictionary_destroy()
This function deallocates all memory associated with a dictionary object. It is passed a pointer to the first and empty key value pair. This function then returns a NULL pointer to the dictionary object.

### dictionary print()
This function prints the entire dictionary including previous and next linked list pointers, as well as the key value pairs. This function is passed a pointer to the first and empty entry in the dictionary. This function has no return.
