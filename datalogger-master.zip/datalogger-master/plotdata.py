# Connor Noddin
# ECE 331 Project 3

import sqlite3
import time
from datetime import datetime, timedelta
import sys
import dateutil.parser

import numpy as np
import matplotlib.pyplot as plt
import matplotlib.dates as mdates

def plot_data(): 
	# Connect to database
	connect = sqlite3.connect('/home/pi/project3/tempdata.db')
	db = connect.cursor()
	
	# Get data from database
	db.execute("SELECT * FROM temperature_data")
	rows = db.fetchall()

	# Preallocate Vectors
	coreTemps = []
	roomTemps = []
	times = []
	# stimes includes only the times that are plotted (last 24 hours)
	stimes = []

	# Put data into vectors
	for row in rows:
		coreTemps.append(row[1])
		roomTemps.append(row[2])
		times.append(row[3])
		
	#Vectors just for plotting	
	plotCore = []
	plotRoom = []
		
	# Current time used for calculation. At time of plotting, only last 24 hours
	# should be shown	
	past = (datetime.now().astimezone().replace(microsecond=0) - timedelta(minutes=1440)) 
	
	for i in range(0,len(times)-1):
		val = times[i]
		insert = dateutil.parser.isoparse(val)
		# Only grabs last 24 hours worth of data, at time of plotting.
		if insert > past:
			# Includes formatting for appearance on graph
			stimes.append(dateutil.parser.isoparse(val).strftime('%Y-%m-%d %I:%M %p'))
			#stimes.append(val)
			plotCore.append(coreTemps[i])
			plotRoom.append(roomTemps[i])
		
	
	#Makes ticks more readable and impactful
	a = len(stimes)
	labels = (stimes[0], stimes[int(a/4)], stimes[int(a/2)], stimes[int(3*a/4)], stimes[int(a)-1])
	my_ticks = np.linspace(0, a, 5, dtype=int)

	#Figure with all formatting
	fig = plt.figure()
	axes = plt.gca()
	plt.gcf().subplots_adjust(bottom=0.2)
	plt.plot(plotCore, label='CPU Temperature')
	plt.plot(plotRoom, label='Room Temperature')
	axes.set_xlim([0,a])
	axes.set_xticks(my_ticks)
	axes.set_xticklabels(labels, rotation = 45, ha = 'right')
	axes.tick_params(axis='both', which='major', labelsize=11)
	plt.legend()
	plt.grid()
	plt.title('Raspberry Pi 4 Temperature Logging', fontsize=20)
	plt.ylabel('Temperature (\N{DEGREE SIGN}C)', fontsize=14)
	plt.xlabel('Time (YYYY-MM-DD HH:MM)', fontsize=14)
	plt.tight_layout()
	#Location in file directory of the .php file the user views
	fig.savefig('/var/www/html/plot.png')
	plt.clf()
	
	connect.close()

# Run python program as script, catching errors
def main():
	try:
		plot_data()
		sys.exit(0)
	except Exception as error:
		print(error)
		print("Error: Failed to plot database")
		sys.exit(-1)

if __name__ == '__main__':
	main()
