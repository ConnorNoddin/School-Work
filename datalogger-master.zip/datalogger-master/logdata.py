# Connor Noddin
# ECE 331 Project 3

import sqlite3 as sq 
import time
import sys
import subprocess
import datetime

def get_data():
	# Open the database
	connect = sq.connect('/home/pi/project3/tempdata.db')
	db = connect.cursor()
	
	# Gets current date and time in ISO 8601 format
	# Includes timezone information without inclusion of microseconds (no need)
	time = datetime.datetime.now().astimezone().replace(microsecond=0).isoformat()

	# Get data from sensor in celcius
	temp = subprocess.check_output(['/usr/sbin/i2cget', '-y', '1', '0x48', '0', 'b'])
	c = int(temp, 16)

	# Get core temperature data
	fd = open("/sys/class/thermal/thermal_zone0/temp", "r")
	rawtemp = fd.readline().split()
	coretemp = int(rawtemp[0])/1000
	
	# Final data structure for sql database
	db_data = (coretemp, c, time)

	# Adds data to database
	connect.execute('INSERT INTO temperature_data(cputemp, roomtemp, time) values(?, ?, ?);', db_data)
	#Debugging output
	#print("Coretemp: " + str(coretemp) + " C Room Temp: " + str(c) + " C Current Time: " + str(time))

	# Clean up files
	fd.close()
	connect.commit()
	connect.close() 

# Run python program as script, catching errors
def main():
	try:
		get_data()
		sys.exit(0)
	except Exception as error:
		print(error)
		print("Error: Failed to add data to database")
		sys.exit(-1)

if __name__ == '__main__':
	main()
