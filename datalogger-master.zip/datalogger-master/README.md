# Data Logger ECE 331 Spring 2022 Project 03

## Description
This is a Raspberry Pi data logger and web server used to plot the data. It reads the room temperature from a TC74 microchip and CPU core temperature from the sysfs interface. The web server uses Lighttpd. Data is logged once per minute.

## Authors
Connor Noddin

## URL
https://connornoddin.com/datalogger.php

## Web Server Setup
First, install the web server Lighttpd. Commands will be done on Raspberry Pi OS
```
sudo apt update

sudo apt upgrade

sudo apt install lighttpd

sudo systemctl start lighttpd

sudo systemctl enable lighttpd

sudo usermod -G www-data -a pi

sudo chown -R www-data:www-data /var/www/html

sudo chmod -R 760 /var/www/html

sudo service lighttpd force-reload
```
This will install the webserver, have it start at boot time, and add the user "Pi" to the group
of users who can access the web server. It will also set relatively secure permissions for the server.

Then we need to install SQL and PHP. Again, commands will be done on Raspberry Pi OS
```
sudo apt install sqlite3

sudo apt install php7.4 php7.4-fpm php7.4-cgi

sudo lighttpd-enable-mod fastcgi-php

sudo service lighttpd force-reload
```
This will install Sqlite3 and PHP for the server. It will also enable it in the configuration.

## Data Logger Configuration
First, make a directory for storing the scripts that will operate the data logging
```
mkdir /home/pi/project3
cd /home/pi/project3
touch logfile
```
now add the "logdata.py" and "plotdata.py" scripts to this directory. logfile will be used to save errors
```
mv datalogger/logdata.py /home/pi/project3
mv datalogger/plotdata.py /home/pi/project3
```

Additionally, we want these scripts to be automated. Therefore, we must add their entries to the cron tab as user Pi
```
crontab -e
```
add
```
* * * * * /usr/bin/python /home/pi/project3/logdata.py >> /home/pi/project3/logfile 2>&1
* * * * * /usr/bin/python /home/pi/project3/plotdata.py >> /home/pi/project3/logfile 2>&1
```
This will tell cron to run these 2 scripts every minute of every day. Any errors messages will be saved to the log file. If an error does occur, however, the web server will continue to operate correctly. Errors are handled using try except blocks in the scripts

## SQl Configuration
While still in the project 3 directory, create the database
```
sqlite3 /home/pi/project3/tempdata.db
```
Then open the database using
```
sqlite3 tempdata.db
```
Add the required table for this project
```
CREATE TABLE tempdata(ID INTEGER PRIMARY KEY AUTOINCREMENT, cputemp REAL, roomtemp REAL, time TEXT);
.quit
```
This adds the table then quits. Time is added as text per ISO format.

## Lighttpd Configuration
Move to the working website directory
```
cd /var/www/html
```
Add "datalogger.php" and "styles.css" to this directory. Also ensure permissions are up to date.
```
mv datalogger/datalogger.php /var/www/html
mv datalogger/styles.css /var/www/html
chown -R www-data:www-data /var/www/html
sudo chmod 644 datalogger.php styles.css
```
Then, edit the lighttpd config file
```
vim /etc/lighttpd/lighttpd.conf
```
Make sure this information is present
```
server.document-root        = "/var/www/html"
server.upload-dirs          = ( "/var/cache/lighttpd/uploads" )
server.errorlog             = "/var/log/lighttpd/error.log"
server.pid-file             = "/run/lighttpd.pid"
server.username             = "www-data"
server.groupname            = "www-data"
```
Finally, while in /var/www/html
```
touch index.html
```
This makes sure an index file is present, however we will not be using it. The web server will be accessible from *IPADDRESS/datalogger.php*

## Finishing up
The web server should now be accessible from your public IP address. Depending on your networking configuration, this may require port forwarding. Be very careful when opening up your Raspberry Pi to the public internet. Disable unused services such as TELNET. Additionally, disable password authentication for SSH. Used key based authentication only. Ensure all passwords for all users are strong. Keep the web server up to date to prevent vulnerabilities.

Be sure to monitor /home/pi/project3/logfile. This will help you view errors associated with the scripting.

